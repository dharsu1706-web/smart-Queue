import React, { useState } from 'react';
import { 
  Building2, 
  Stethoscope, 
  User, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  QrCode, 
  Activity, 
  AlertTriangle,
  XCircle,
  Download,
  Share2,
  Sparkles
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { ALTERNATE_HOSPITALS } from '../../data/mockData';
import { PriorityCategory, QueueToken, VisitType } from '../../types/queue';
import { QRCodeSVG } from 'qrcode.react';

interface TokenGeneratorProps {
  onTokenGenerated: (token: QueueToken) => void;
  onTrackQueue: () => void;
  onCancel: () => void;
}

export const TokenGenerator: React.FC<TokenGeneratorProps> = ({
  onTokenGenerated,
  onTrackQueue,
  onCancel
}) => {
  const { 
    hospitalName, 
    setHospitalName, 
    departments, 
    doctors, 
    currentPatient, 
    generateToken,
    cancelToken 
  } = useQueue();

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [selectedHospital, setSelectedHospital] = useState(hospitalName);
  const [selectedDeptId, setSelectedDeptId] = useState('cardiology');
  const [selectedDocId, setSelectedDocId] = useState('doc-1');
  const [visitType, setVisitType] = useState<VisitType>('appointment');
  const [category, setCategory] = useState<PriorityCategory>(currentPatient.category || 'general');
  const [symptoms, setSymptoms] = useState('');
  const [generatedToken, setGeneratedToken] = useState<QueueToken | null>(null);

  // Filter doctors for the selected department
  const filteredDoctors = doctors.filter(doc => doc.departmentId === selectedDeptId);
  const selectedDept = departments.find(d => d.id === selectedDeptId);
  const selectedDoc = doctors.find(d => d.id === selectedDocId) || filteredDoctors[0];

  const handleNext = () => {
    if (currentStep < 4) {
      // If moving to step 3, ensure selected doctor belongs to selected department
      if (currentStep === 2 && filteredDoctors.length > 0) {
        setSelectedDocId(filteredDoctors[0].id);
      }
      setCurrentStep(prev => prev + 1);
    } else {
      // Final Step: Generate token
      const token = generateToken({
        hospitalName: selectedHospital,
        departmentId: selectedDeptId,
        doctorId: selectedDocId || (filteredDoctors[0]?.id ?? 'doc-1'),
        visitType,
        category,
        symptoms
      });
      setGeneratedToken(token);
      onTokenGenerated(token);
      setCurrentStep(5); // Show success view
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    } else {
      onCancel();
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      
      {/* Step Indicator (Steps 1 to 4) */}
      {currentStep <= 4 && (
        <div className="mb-8">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
            <span className={currentStep >= 1 ? 'text-brand-600 font-bold' : ''}>1. Hospital</span>
            <span className={currentStep >= 2 ? 'text-brand-600 font-bold' : ''}>2. Department</span>
            <span className={currentStep >= 3 ? 'text-brand-600 font-bold' : ''}>3. Doctor</span>
            <span className={currentStep >= 4 ? 'text-brand-600 font-bold' : ''}>4. Visit Type</span>
          </div>
          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-brand-600 h-full transition-all duration-300 rounded-full"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Main Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-8">
        
        {/* Step 1: Hospital Selection */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-50 text-brand-700 text-xs font-semibold mb-2">
                <Building2 className="w-3.5 h-3.5" />
                <span>Step 1 of 4</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Select Hospital / Medical Center
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Choose the hospital location where you wish to book your OPD consultation.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {ALTERNATE_HOSPITALS.map((hosp, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setSelectedHospital(hosp);
                    setHospitalName(hosp);
                  }}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition flex items-center justify-between ${
                    selectedHospital === hosp 
                      ? 'border-brand-600 bg-brand-50/50 shadow-sm' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                      selectedHospital === hosp ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}>
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{hosp}</h4>
                      <p className="text-xs text-slate-500">Multispeciality OPD & Diagnostics</p>
                    </div>
                  </div>
                  {selectedHospital === hosp && (
                    <CheckCircle2 className="w-5 h-5 text-brand-600" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Department Selection */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-50 text-brand-700 text-xs font-semibold mb-2">
                <Stethoscope className="w-3.5 h-3.5" />
                <span>Step 2 of 4</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Select Department
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Select the specialty department you require. Real-time waiting times are shown below.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[420px] overflow-y-auto pr-1">
              {departments.map((dept) => (
                <div
                  key={dept.id}
                  onClick={() => setSelectedDeptId(dept.id)}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition flex flex-col justify-between space-y-2 ${
                    selectedDeptId === dept.id 
                      ? 'border-brand-600 bg-brand-50/50 shadow-sm' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        Code: {dept.code}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 mt-1">{dept.name}</h4>
                    </div>
                    {selectedDeptId === dept.id && (
                      <CheckCircle2 className="w-5 h-5 text-brand-600 shrink-0" />
                    )}
                  </div>

                  <p className="text-[11px] text-slate-500 line-clamp-2">
                    {dept.description}
                  </p>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Wait: <strong className="text-slate-800 font-bold">{dept.avgWaitMinutes}m</strong></span>
                    <span className="font-mono text-emerald-600 font-bold">Serving {dept.currentServingToken}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Doctor Selection */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-50 text-brand-700 text-xs font-semibold mb-2">
                <User className="w-3.5 h-3.5" />
                <span>Step 3 of 4</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Select Doctor in {selectedDept?.name}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Choose an available specialist physician or consultant.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {filteredDoctors.length > 0 ? (
                filteredDoctors.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDocId(doc.id)}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition flex items-center justify-between ${
                      selectedDocId === doc.id 
                        ? 'border-brand-600 bg-brand-50/50 shadow-sm' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3.5">
                      <img 
                        src={doc.avatar} 
                        alt={doc.name} 
                        className="w-12 h-12 rounded-xl object-cover border border-slate-200" 
                      />
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="text-sm font-bold text-slate-900">{doc.name}</h4>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold capitalize ${
                            doc.status === 'available' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {doc.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">{doc.specialty}</p>
                        <p className="text-[11px] text-brand-600 mt-0.5">{doc.room}</p>
                      </div>
                    </div>
                    {selectedDocId === doc.id && (
                      <CheckCircle2 className="w-5 h-5 text-brand-600" />
                    )}
                  </div>
                ))
              ) : (
                <div className="p-6 text-center text-slate-500 text-xs">
                  No specific doctor rostered in this department. General duty clinician will be assigned automatically.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Step 4: Visit Type & Patient Category */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-50 text-brand-700 text-xs font-semibold mb-2">
                <Calendar className="w-3.5 h-3.5" />
                <span>Step 4 of 4</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Visit Details & Priority Category
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Choose whether you have a booked appointment or are a walk-in, and review your priority group.
              </p>
            </div>

            {/* Visit Type Toggle */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                Visit Type
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div
                  onClick={() => setVisitType('appointment')}
                  className={`p-3.5 rounded-xl border-2 cursor-pointer transition text-center ${
                    visitType === 'appointment' ? 'border-brand-600 bg-brand-50/50' : 'border-slate-200'
                  }`}
                >
                  <Calendar className="w-5 h-5 mx-auto mb-1 text-brand-600" />
                  <div className="text-xs font-bold text-slate-900">Appointment</div>
                  <div className="text-[10px] text-slate-500">Pre-booked scheduled slot</div>
                </div>

                <div
                  onClick={() => setVisitType('walk-in')}
                  className={`p-3.5 rounded-xl border-2 cursor-pointer transition text-center ${
                    visitType === 'walk-in' ? 'border-brand-600 bg-brand-50/50' : 'border-slate-200'
                  }`}
                >
                  <Clock className="w-5 h-5 mx-auto mb-1 text-brand-600" />
                  <div className="text-xs font-bold text-slate-900">Walk-In</div>
                  <div className="text-[10px] text-slate-500">Same-day OPD registration</div>
                </div>
              </div>
            </div>

            {/* Priority Group */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Patient Priority Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PriorityCategory)}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white"
              >
                <option value="general">General</option>
                <option value="senior">Senior Citizen (60+)</option>
                <option value="pregnant">Pregnant Mother</option>
                <option value="child">Child / Infant (&lt;12)</option>
                <option value="pwd">Person with Disability</option>
                <option value="emergency">Emergency / Urgent Care</option>
              </select>
              <p className="text-[10px] text-slate-400 mt-1">
                Priority status will be validated by hospital triage staff upon arrival.
              </p>
            </div>

            {/* Symptoms summary */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Chief Symptoms or Reason for Visit (Optional)
              </label>
              <textarea
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder="e.g. Mild chest pain, fever for 2 days, routine blood test review..."
                rows={2}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>
        )}

        {/* Step 5: Token Generated Success Screen */}
        {currentStep === 5 && generatedToken && (
          <div className="text-center space-y-6 animate-in fade-in zoom-in-95 duration-200">
            
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
                Digital Token Successfully Issued!
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-1">
                Your Token: <span className="text-brand-600">{generatedToken.tokenNumber}</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {generatedToken.hospitalName} • {generatedToken.departmentName}
              </p>
            </div>

            {/* Prominent QR Code */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 inline-block mx-auto shadow-inner">
              <QRCodeSVG
                value={`SMARTQUEUE:${generatedToken.tokenNumber}|${generatedToken.patientName}|${generatedToken.doctorName}|${generatedToken.estimatedWaitMinutes}min`}
                size={160}
                level="H"
              />
              <div className="text-[10px] font-mono text-slate-500 mt-2 uppercase">
                Scan Pass: {generatedToken.tokenNumber}
              </div>
            </div>

            {/* Live Queue Status Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] text-slate-400">Patients Ahead</div>
                <div className="text-xl font-bold text-amber-600 mt-0.5">{generatedToken.patientsAhead}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] text-slate-400">Current Serving</div>
                <div className="text-xl font-bold text-emerald-600 font-mono mt-0.5">{generatedToken.currentServingToken}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] text-slate-400">AI Est. Wait</div>
                <div className="text-xl font-bold text-brand-600 mt-0.5">{generatedToken.estimatedWaitMinutes} min</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] text-slate-400">AI Confidence</div>
                <div className="text-xl font-bold text-purple-600 mt-0.5">{generatedToken.aiConfidencePercent}%</div>
              </div>
            </div>

            {/* Doctor & Room info */}
            <div className="p-3 rounded-xl bg-brand-50/60 border border-brand-200 text-xs text-slate-700 text-left flex items-center justify-between">
              <div>
                <strong>{generatedToken.doctorName}</strong>
                <div className="text-[11px] text-brand-700">{generatedToken.doctorRoom}</div>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-brand-700 border border-brand-200">
                {generatedToken.visitType.toUpperCase()}
              </span>
            </div>

            {/* Required Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={onTrackQueue}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center justify-center space-x-2"
              >
                <Activity className="w-4 h-4" />
                <span>Track Queue Live</span>
              </button>

              <button
                onClick={() => window.print()}
                className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition flex items-center justify-center space-x-2"
              >
                <Download className="w-4 h-4" />
                <span>Download / Print Token</span>
              </button>

              <button
                onClick={() => {
                  cancelToken(generatedToken.id);
                  onCancel();
                }}
                className="w-full sm:w-auto px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 text-xs sm:text-sm font-semibold transition"
              >
                Cancel Token
              </button>
            </div>

          </div>
        )}

        {/* Step Navigation Footer (for Steps 1-4) */}
        {currentStep <= 4 && (
          <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={handleBack}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition flex items-center space-x-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{currentStep === 1 ? 'Cancel' : 'Back'}</span>
            </button>

            <button
              type="button"
              onClick={handleNext}
              className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center space-x-2"
            >
              <span>{currentStep === 4 ? 'Generate Digital Token' : 'Continue'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>

    </div>
  );
};
