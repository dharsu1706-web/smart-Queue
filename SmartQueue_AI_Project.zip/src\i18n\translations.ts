export type Language = 'en' | 'ta';

export interface Translations {
  // Brand & Nav
  appName: string;
  tagline: string;
  home: string;
  howItWorks: string;
  features: string;
  forHospitals: string;
  about: string;
  patientPortal: string;
  hospitalLogin: string;
  kioskDisplay: string;
  switchPortal: string;
  resetDemo: string;
  live: string;

  // Hero
  heroTitle1: string;
  heroTitleHighlight: string;
  heroSubtitle: string;
  uspConcept: string;
  getTokenBtn: string;
  hospitalLoginBtn: string;
  lessWaiting: string;
  lessCrowding: string;
  betterEfficiency: string;
  betterExperience: string;

  // 4 Highlights
  digitalTokenTitle: string;
  digitalTokenDesc: string;
  realtimeTrackingTitle: string;
  realtimeTrackingDesc: string;
  aiPredictionTitle: string;
  aiPredictionDesc: string;
  smartNotifTitle: string;
  smartNotifDesc: string;

  // Patient Dashboard
  welcomeBack: string;
  patientId: string;
  activeTokenBadge: string;
  yourTokenNumber: string;
  patientsAhead: string;
  currentServing: string;
  aiEstWait: string;
  minutes: string;
  trackQueueLive: string;
  explainAi: string;
  confirmReturn: string;
  contactlessQrPass: string;
  scanPassPrompt: string;
  getNewToken: string;

  // Live Queue Tracker
  queueStatusTitle: string;
  lastUpdated: string;
  pipelineCompleted: string;
  pipelineServing: string;
  pipelineYourToken: string;
  pipelineRemaining: string;
  doctorStatus: string;
  queueStatus: string;
  advanceSimulate: string;

  // Return Alert
  turnApproachingTitle: string;
  turnApproachingMsg: string;
  estRemainingTime: string;
  returnNowMsg: string;
  returnNowBtn: string;
  snoozeBtn: string;
  viewQueueBtn: string;
  enRouteConfirmedMsg: string;

  // AI Prediction
  aiTitle: string;
  aiSubtitle: string;
  confidence: string;
  factorQueue: string;
  factorDoctor: string;
  factorWorkload: string;
  factorAvgTime: string;

  // Kiosk
  kioskTitle: string;
  nowServing: string;
  waitingInQueue: string;
  exitKiosk: string;

  // Priority
  emergency: string;
  senior: string;
  pregnant: string;
  child: string;
  pwd: string;
  general: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: 'SmartQueue AI',
    tagline: 'Smart Hospital Queue Management System',
    home: 'Home',
    howItWorks: 'How It Works',
    features: 'Features',
    forHospitals: 'For Hospitals',
    about: 'About',
    patientPortal: 'Patient Portal',
    hospitalLogin: 'Hospital Login',
    kioskDisplay: 'Waiting TV Kiosk',
    switchPortal: 'Switch Portal',
    resetDemo: 'Reset Demo Data',
    live: 'Live',

    heroTitle1: 'Smart Hospital Queues.',
    heroTitleHighlight: 'Less Waiting. Better Care.',
    heroSubtitle: 'Get your digital token, track your queue in real time, and know exactly when to return.',
    uspConcept: '“Don’t wait in the hospital — know when to return.”',
    getTokenBtn: 'Get Digital Token',
    hospitalLoginBtn: 'Hospital Login',
    lessWaiting: '✓ Less Waiting',
    lessCrowding: '✓ Less Crowding',
    betterEfficiency: '✓ Better Efficiency',
    betterExperience: '✓ Better Patient Experience',

    digitalTokenTitle: 'Digital Token',
    digitalTokenDesc: 'Generate contactless QR tokens from your mobile phone. Eliminates manual reception lines completely.',
    realtimeTrackingTitle: 'Real-Time Queue Tracking',
    realtimeTrackingDesc: 'Live updates on current serving token, exact patients ahead of you, and doctor consultation progression.',
    aiPredictionTitle: 'AI Waiting-Time Prediction',
    aiPredictionDesc: 'Calculates waiting time with 85-95% confidence based on patient flow, doctor speed, and department workload.',
    smartNotifTitle: 'Smart Notifications',
    smartNotifDesc: 'Receive proactive “Return Now” alerts at 15m and 10m intervals, doctor delay warnings, and instant emergency alerts.',

    welcomeBack: 'Welcome back',
    patientId: 'Patient ID',
    activeTokenBadge: 'Active Digital Token',
    yourTokenNumber: 'Your Digital Token Number',
    patientsAhead: 'Patients Ahead',
    currentServing: 'Current Serving',
    aiEstWait: 'AI Est. Wait',
    minutes: 'min',
    trackQueueLive: 'Track Queue Live',
    explainAi: 'View AI Prediction Model',
    confirmReturn: 'Confirm I Am Returning',
    contactlessQrPass: 'Contactless QR Pass',
    scanPassPrompt: 'Scan at hospital entrance or clinic door',
    getNewToken: '+ Get Digital Token',

    queueStatusTitle: 'Live Queue Radar & Tracker',
    lastUpdated: 'Last updated',
    pipelineCompleted: 'Completed',
    pipelineServing: 'Current Serving',
    pipelineYourToken: 'Your Token',
    pipelineRemaining: 'Remaining',
    doctorStatus: 'Doctor Status',
    queueStatus: 'Queue Status',
    advanceSimulate: 'Advance Queue (Simulate)',

    turnApproachingTitle: '🔔 Your Turn Is Approaching!',
    turnApproachingMsg: 'Your token will be called soon. You can start returning to the hospital now.',
    estRemainingTime: 'Estimated Time Remaining',
    returnNowMsg: '“You can start returning to the hospital now.”',
    returnNowBtn: 'Return Now (En Route)',
    snoozeBtn: 'Snooze Alert',
    viewQueueBtn: 'View Live Queue',
    enRouteConfirmedMsg: '✓ Reception notified you are en route',

    aiTitle: 'AI Waiting-Time Prediction',
    aiSubtitle: 'Dynamically synthesized using real-time patient flow, clinician consultation pace, and workload index.',
    confidence: 'Confidence',
    factorQueue: 'Current Queue Flow',
    factorDoctor: 'Doctor Availability',
    factorWorkload: 'Department Workload',
    factorAvgTime: 'Avg Consultation Time',

    kioskTitle: 'Outpatient Department • Live Token Display',
    nowServing: 'NOW SERVING TOKEN',
    waitingInQueue: 'Waiting in queue',
    exitKiosk: 'Exit Kiosk',

    emergency: 'Emergency',
    senior: 'Senior Citizen',
    pregnant: 'Pregnant',
    child: 'Child',
    pwd: 'Person with Disability',
    general: 'General'
  },
  ta: {
    appName: 'ஸ்மார்ட்கியூ AI',
    tagline: 'ஸ்மார்ட் மருத்துவமனை வரிசை மேலாண்மை அமைப்பு',
    home: 'முகப்பு',
    howItWorks: 'எப்படி இயங்குகிறது',
    features: 'சிறப்பம்சங்கள்',
    forHospitals: 'மருத்துவமனைகளுக்கு',
    about: 'விவரம்',
    patientPortal: 'நோயாளி தளம்',
    hospitalLogin: 'மருத்துவமனை உள்நுழைவு',
    kioskDisplay: 'காத்திருப்பு அறை டிவி',
    switchPortal: 'தளத்தை மாற்று',
    resetDemo: 'டெமோ தரவை மீட்டமை',
    live: 'நேரலை',

    heroTitle1: 'ஸ்மார்ட் மருத்துவமனை வரிசைகள்.',
    heroTitleHighlight: 'குறைந்த காத்திருப்பு. சிறந்த சிகிச்சை.',
    heroSubtitle: 'டிஜிட்டல் டோக்கனைப் பெறுங்கள், வரிசையை நேரலையாகக் கண்காணியுங்கள், எப்போது வர வேண்டும் என்பதை அறிந்து கொள்ளுங்கள்.',
    uspConcept: '“மருத்துவமனையில் காத்திருக்க வேண்டாம் — எப்போது வர வேண்டும் என்பதைத் தெரிந்து கொள்ளுங்கள்!”',
    getTokenBtn: 'டிஜிட்டல் டோக்கன் பெறுக',
    hospitalLoginBtn: 'மருத்துவமனை லாகின்',
    lessWaiting: '✓ குறைந்த காத்திருப்பு',
    lessCrowding: '✓ குறைவான நெரிசல்',
    betterEfficiency: '✓ சிறந்த செயல்திறன்',
    betterExperience: '✓ அமைதியான அனுபவம்',

    digitalTokenTitle: 'டிஜிட்டல் டோக்கன்',
    digitalTokenDesc: 'மொபைல் மூலம் காகிதமில்லா QR டோக்கன். வரவேற்பறை நீண்ட வரிசைகளை முழுமையாகத் தவிர்க்கிறது.',
    realtimeTrackingTitle: 'நிகழ்நேர வரிசைக் கண்காணிப்பு',
    realtimeTrackingDesc: 'தற்போது பார்க்கப்படும் டோக்கன், உங்களுக்கு முன்னால் உள்ளவர்களின் எண்ணிக்கை மற்றும் மருத்துவர் நிலை.',
    aiPredictionTitle: 'AI காத்திருப்பு நேரக் கணிப்பு',
    aiPredictionDesc: 'நோயாளி ஓட்டம், மருத்துவர் வேகம் மற்றும் துறை பணிச்சுமை அடிப்படையில் 85-95% துல்லியமான நேரம்.',
    smartNotifTitle: 'ஸ்மார்ட் அறிவிப்புகள்',
    smartNotifDesc: 'உங்கள் முறைக்கு 15 மற்றும் 10 நிமிடங்கள் முன்பாக புறப்படச் சொல்லும் “Return Now” எச்சரிக்கை அறிவிப்புகள்.',

    welcomeBack: 'வணக்கம்',
    patientId: 'நோயாளி எண்',
    activeTokenBadge: 'செயலில் உள்ள டிஜிட்டல் டோக்கன்',
    yourTokenNumber: 'உங்கள் டோக்கன் எண்',
    patientsAhead: 'முன்னால் உள்ளவர்கள்',
    currentServing: 'தற்போது பார்ப்பது',
    aiEstWait: 'AI கணித்த நேரம்',
    minutes: 'நிமிடம்',
    trackQueueLive: 'நேரலையாகக் காண்க',
    explainAi: 'AI கணிப்பு முறையைப் பார்',
    confirmReturn: 'நான் புறப்பட்டுவிட்டேன்',
    contactlessQrPass: 'காண்டாக்ட்லெஸ் QR பாஸ்',
    scanPassPrompt: 'மருத்துவமனை நுழைவாயில் அல்லது அறையில் ஸ்கேன் செய்யவும்',
    getNewToken: '+ புதிய டோக்கன் பெறுக',

    queueStatusTitle: 'நேரலை வரிசை ரேடார் & டிராக்கர்',
    lastUpdated: 'கடைசியாக புதுப்பித்தது',
    pipelineCompleted: 'முடிந்தது',
    pipelineServing: 'தற்போது பார்ப்பது',
    pipelineYourToken: 'உங்கள் டோக்கன்',
    pipelineRemaining: 'அடுத்தவை',
    doctorStatus: 'மருத்துவர் நிலை',
    queueStatus: 'வரிசை நிலை',
    advanceSimulate: 'வரிசையை முன்னோக்கு (சிமுலேஷன்)',

    turnApproachingTitle: '🔔 உங்கள் முறை நெருங்குகிறது!',
    turnApproachingMsg: 'உங்கள் டோக்கன் விரைவில் அழைக்கப்படும். நீங்கள் இப்போது மருத்துவமனைக்குப் புறப்படலாம்.',
    estRemainingTime: 'மீதமுள்ள உத்தேச நேரம்',
    returnNowMsg: '“மருத்துவமனைக்கு உடனடியாகப் புறப்படவும் — நேரத்திற்கு வரவும்.”',
    returnNowBtn: 'புறப்பட்டுவிட்டேன் (Return Now)',
    snoozeBtn: 'தள்ளிவை (Snooze)',
    viewQueueBtn: 'வரிசையைப் பார்',
    enRouteConfirmedMsg: '✓ நீங்கள் புறப்பட்டுவிட்ட தகவல் வரவேற்பறைக்குத் தெரிவிக்கப்பட்டது',

    aiTitle: 'AI காத்திருப்பு நேரக் கணிப்பு இயந்திரம்',
    aiSubtitle: 'நிகழ்நேர நோயாளி எண்ணிக்கை, மருத்துவர் ஆலோசனை வேகம் மற்றும் பணிச்சுமை அடிப்படையில் கணக்கிடப்பட்டது.',
    confidence: 'துல்லியம்',
    factorQueue: 'வரிசையில் உள்ளோர் எண்ணிக்கை',
    factorDoctor: 'மருத்துவர் இருப்பு நிலை',
    factorWorkload: 'துறை பணிச்சுமை குறியீடு',
    factorAvgTime: 'சராசரி பரிசோதனை நேரம்',

    kioskTitle: 'புறநோயாளிகள் பிரிவு • நேரலை டோக்கன் திரை',
    nowServing: 'தற்போது அழைக்கப்படும் டோக்கன்',
    waitingInQueue: 'காத்திருப்போர் எண்ணிக்கை',
    exitKiosk: 'வெளியேறு',

    emergency: 'அவசரம்',
    senior: 'மூத்த குடிமக்கள் (60+)',
    pregnant: 'கர்ப்பிணிகள்',
    child: 'குழந்தைகள்',
    pwd: 'மாற்றுத்திறனாளிகள்',
    general: 'பொதுப் பிரிவு'
  }
};
