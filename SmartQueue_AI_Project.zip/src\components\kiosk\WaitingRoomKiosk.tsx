import React, { useState, useEffect } from 'react';
import { 
  Tv, 
  Volume2, 
  Clock, 
  Activity, 
  Building2, 
  ArrowLeft,
  Sparkles,
  AlertTriangle,
  Globe
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { useLanguage } from '../../context/LanguageContext';

interface WaitingRoomKioskProps {
  onBackToApp: () => void;
}

export const WaitingRoomKiosk: React.FC<WaitingRoomKioskProps> = ({ onBackToApp }) => {
  const { hospitalName, departments, tokens } = useQueue();
  const { t, language, toggleLanguage } = useLanguage();
  const [time, setTime] = useState(new Date().toLocaleTimeString());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const emergencyToken = tokens.find(
    t => (t.patientCategory === 'emergency' || t.isEmergencyOverride) && t.status === 'serving'
  );

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col p-4 sm:p-8 select-none">
      
      {/* 1. Kiosk Top Bar */}
      <div className="flex items-center justify-between pb-6 border-b border-slate-800">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-500/30">
            <Activity className="w-7 h-7 animate-pulse" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              {hospitalName}
            </h1>
            <p className="text-xs text-brand-400 font-semibold tracking-wider uppercase">
              {t.kioskTitle}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-900 text-xs font-bold text-white hover:bg-slate-800 transition flex items-center space-x-1.5"
          >
            <Globe className="w-3.5 h-3.5 text-brand-400" />
            <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
          </button>

          <div className="text-right">
            <div className="text-2xl sm:text-3xl font-mono font-bold text-white tracking-wider">
              {time}
            </div>
            <div className="text-xs text-slate-400">
              {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
          </div>

          <button
            onClick={onBackToApp}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition flex items-center space-x-1.5"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{t.exitKiosk}</span>
          </button>
        </div>
      </div>

      {/* 2. Emergency Broadcast Banner (if any) */}
      {emergencyToken && (
        <div className="my-4 p-4 rounded-2xl bg-red-600 text-white font-black text-center text-lg sm:text-xl flex items-center justify-center space-x-3 emergency-pulse">
          <AlertTriangle className="w-6 h-6 animate-bounce" />
          <span>
            {language === 'ta' 
              ? `அவசர முன்னுரிமை: டோக்கன் ${emergencyToken.tokenNumber} உடனடியாக ${emergencyToken.doctorRoom}-க்கு வரவும்!`
              : `EMERGENCY PRIORITY: TOKEN ${emergencyToken.tokenNumber} TO ${emergencyToken.doctorRoom.toUpperCase()} IMMEDIATELY`}
          </span>
        </div>
      )}

      {/* 3. Big Screen Department Token Grid */}
      <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 my-6">
        {departments.map((dept) => (
          <div 
            key={dept.id} 
            className="rounded-3xl bg-slate-900 border-2 border-slate-800 p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden group hover:border-brand-500/50 transition-all"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs font-mono font-bold text-brand-400 uppercase">
                  {dept.code} - OPD
                </span>
                <h3 className="text-xl font-black text-white mt-0.5">{dept.name}</h3>
              </div>
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></span>
            </div>

            <div className="py-6 text-center">
              <div className="text-xs uppercase font-extrabold tracking-widest text-slate-400 mb-1">
                {t.nowServing}
              </div>
              <div className="text-6xl sm:text-7xl font-mono font-black text-emerald-400 tracking-tight drop-shadow-md">
                {dept.currentServingToken}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 font-medium">
              <span>{t.waitingInQueue}: <strong className="text-white">{dept.totalWaiting}</strong></span>
              <span>{language === 'ta' ? 'உத்தேச நேரம்:' : 'Avg Est. Wait:'} <strong className="text-brand-300">{dept.avgWaitMinutes} {t.minutes}</strong></span>
            </div>
          </div>
        ))}
      </div>

      {/* 4. Ticker Footnote */}
      <div className="pt-4 border-t border-slate-800 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span className="flex items-center text-brand-400 font-semibold">
          <Sparkles className="w-4 h-4 mr-1.5" />
          {t.appName}: {t.uspConcept}
        </span>
        <span>
          {language === 'ta'
            ? 'அழைப்பு வருவதற்கு 10 நிமிடங்களுக்கு முன் நோயாளிகளுக்கு SMS & ஆப் மூலம் அறிவிக்கப்படும்.'
            : 'Patients are notified 10 minutes prior to token call via App & SMS.'}
        </span>
      </div>

    </div>
  );
};
