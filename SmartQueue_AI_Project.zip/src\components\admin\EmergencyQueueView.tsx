import React, { useState } from 'react';
import { 
  AlertOctagon, 
  ShieldAlert, 
  PhoneCall, 
  CheckCircle2, 
  Clock, 
  Sparkles,
  ArrowRight,
  UserCheck
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { QueueToken } from '../../types/queue';

export const EmergencyQueueView: React.FC = () => {
  const { tokens, callNextToken, updatePatientPriority } = useQueue();
  const [selectedTokenForEmergency, setSelectedTokenForEmergency] = useState<QueueToken | null>(null);

  // All tokens flagged as emergency or high priority
  const emergencyTokens = tokens.filter(
    t => (t.patientCategory === 'emergency' || t.isEmergencyOverride) && (t.status === 'waiting' || t.status === 'approaching' || t.status === 'serving')
  );

  const nonEmergencyTokens = tokens.filter(
    t => t.patientCategory !== 'emergency' && !t.isEmergencyOverride && (t.status === 'waiting' || t.status === 'approaching')
  );

  const handleConfirmEmergency = () => {
    if (selectedTokenForEmergency) {
      updatePatientPriority(selectedTokenForEmergency.id, 'emergency', true);
      setSelectedTokenForEmergency(null);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Urgent Alert Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4 emergency-pulse">
        <div className="flex items-start space-x-3.5">
          <div className="p-2.5 bg-white/20 rounded-xl mt-0.5">
            <AlertOctagon className="w-8 h-8 animate-bounce" />
          </div>
          <div>
            <div className="text-xs uppercase font-extrabold tracking-wider text-red-100">
              Immediate Clinical Care Lane
            </div>
            <h2 className="text-2xl font-black">
              Dedicated Emergency & Critical Triage Queue
            </h2>
            <p className="text-xs text-red-100 mt-1 max-w-xl">
              Emergency tokens automatically preempt standard queue priority. Real-time auditory and visual alerts are broadcast to attending physicians.
            </p>
          </div>
        </div>

        <div className="bg-white/10 px-4 py-3 rounded-xl border border-white/20 text-center shrink-0">
          <div className="text-[10px] uppercase font-bold text-red-200">Active Urgent Cases</div>
          <div className="text-3xl font-black">{emergencyTokens.length}</div>
        </div>
      </div>

      {/* 2. Active Emergency Patients Table */}
      <div className="bg-white rounded-2xl border-2 border-red-200 overflow-hidden card-shadow">
        <div className="p-4 bg-red-50 border-b border-red-200 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-red-600" />
            <h3 className="text-sm font-extrabold text-red-950 uppercase tracking-wider">
              Prioritized Emergency Outpatients
            </h3>
          </div>
          <span className="text-xs font-bold text-red-700">Immediate Cabin Call</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-600 text-xs font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Token</th>
                <th className="py-3 px-4">Patient Name & Age</th>
                <th className="py-3 px-4">Department & Doctor</th>
                <th className="py-3 px-4">Symptoms / Triage Note</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {emergencyTokens.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                    No active emergency priority tokens pending. Triage operational.
                  </td>
                </tr>
              ) : (
                emergencyTokens.map((tok) => (
                  <tr key={tok.id} className="bg-red-50/40 hover:bg-red-50 transition font-semibold">
                    <td className="py-3.5 px-4">
                      <span className="font-mono text-lg font-black text-red-600">
                        {tok.tokenNumber}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-900">
                      {tok.patientName} ({tok.patientAge}y)
                    </td>
                    <td className="py-3.5 px-4 text-slate-800">
                      <div>{tok.departmentName}</div>
                      <div className="text-[11px] text-brand-600">{tok.doctorName}</div>
                    </td>
                    <td className="py-3.5 px-4 text-xs text-red-800 max-w-xs">
                      {tok.symptoms || 'Acute symptom presentation flagged by triage nurse.'}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-red-600 text-white">
                        {tok.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => callNextToken(tok.departmentId)}
                        className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md transition"
                      >
                        Call to Doctor Now
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Fast Upgrade to Emergency Panel */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            Escalate Patient to Emergency Queue
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Select any waiting OPD patient whose condition has acutely deteriorated to reallocate immediate triage priority.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {nonEmergencyTokens.slice(0, 6).map((tok) => (
            <div 
              key={tok.id} 
              className="p-3.5 rounded-xl border border-slate-200 hover:border-red-300 flex items-center justify-between transition"
            >
              <div>
                <span className="font-mono font-bold text-slate-900 text-sm">{tok.tokenNumber}</span>
                <div className="text-xs font-semibold text-slate-800">{tok.patientName}</div>
                <div className="text-[11px] text-slate-500">{tok.departmentName}</div>
              </div>
              <button
                onClick={() => setSelectedTokenForEmergency(tok)}
                className="px-2.5 py-1 rounded-lg text-xs font-bold bg-red-50 text-red-600 hover:bg-red-100 transition"
              >
                Mark Emergency
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Confirmation Dialog */}
      {selectedTokenForEmergency && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center mx-auto">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Confirm Emergency Triage
              </h3>
              <p className="text-xs text-slate-600">
                Move Token <strong>{selectedTokenForEmergency.tokenNumber}</strong> ({selectedTokenForEmergency.patientName}) to the top of the {selectedTokenForEmergency.departmentName} queue?
              </p>
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <button
                onClick={() => setSelectedTokenForEmergency(null)}
                className="w-1/2 py-2 text-xs font-bold rounded-xl border border-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmEmergency}
                className="w-1/2 py-2 text-xs font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-md"
              >
                Confirm Override
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
