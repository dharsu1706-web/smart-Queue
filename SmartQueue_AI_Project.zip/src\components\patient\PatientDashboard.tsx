import React from 'react';
import { 
  User, 
  Activity, 
  Clock, 
  PlusCircle, 
  QrCode, 
  ChevronRight, 
  AlertCircle, 
  Building2, 
  Stethoscope, 
  MapPin, 
  Calendar, 
  ArrowUpRight,
  Car,
  Bell,
  Sparkles
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { useLanguage } from '../../context/LanguageContext';
import { QRCodeSVG } from 'qrcode.react';

interface PatientDashboardProps {
  onStartTokenGeneration: () => void;
  onTrackQueue: () => void;
  onViewVisits: () => void;
  onViewAIPrediction: () => void;
}

export const PatientDashboard: React.FC<PatientDashboardProps> = ({
  onStartTokenGeneration,
  onTrackQueue,
  onViewVisits,
  onViewAIPrediction
}) => {
  const { currentPatient, activeToken, hospitalName, markEnRoute } = useQueue();
  const { t, language } = useLanguage();

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* 1. Patient Profile & Hospital Overview Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 card-shadow">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-brand-600 to-cyan-500 text-white flex items-center justify-center text-xl font-bold shadow-md shadow-brand-500/20">
              {currentPatient.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  {t.welcomeBack}, {currentPatient.name}
                </h1>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-brand-50 text-brand-700 border border-brand-200">
                  {t.patientId}: {currentPatient.id}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-slate-500 mt-1">
                <span className="flex items-center">
                  <Building2 className="w-3.5 h-3.5 mr-1 text-slate-400" />
                  {hospitalName}
                </span>
                <span className="flex items-center">
                  <User className="w-3.5 h-3.5 mr-1 text-slate-400" />
                  {currentPatient.age} yrs • {currentPatient.gender.toUpperCase()}
                </span>
                <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium capitalize">
                  {language === 'ta' ? 'பிரிவு: ' : 'Priority: '}{t[currentPatient.category] || currentPatient.category}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Action Button */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onStartTokenGeneration}
              className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-brand-500/20 transition active:scale-95 flex items-center justify-center space-x-2"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t.getNewToken}</span>
            </button>
          </div>

        </div>
      </div>

      {/* 2. Primary Active Token Spotlight (e.g. C-127) */}
      {activeToken ? (
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-brand-950 rounded-2xl text-white p-6 sm:p-8 shadow-xl relative overflow-hidden">
          
          {/* Subtle glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-brand-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Column: Token Details */}
            <div className="lg:col-span-8 space-y-4">
              
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider bg-brand-500/30 text-brand-300 border border-brand-400/30 flex items-center">
                  <Sparkles className="w-3.5 h-3.5 mr-1 text-brand-400" /> {t.activeTokenBadge}
                </span>
                <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  {activeToken.visitType === 'appointment' ? (language === 'ta' ? 'முன்பதிவு' : 'Scheduled Appointment') : (language === 'ta' ? 'நேரடி வருகை' : 'Walk-In Consultation')}
                </span>
              </div>

              <div>
                <div className="text-slate-400 text-xs uppercase tracking-wider font-semibold">
                  {t.yourTokenNumber}
                </div>
                <div className="text-4xl sm:text-5xl font-black text-white tracking-tight mt-1">
                  {activeToken.tokenNumber}
                </div>
              </div>

              {/* Consultation Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/80">
                  <div className="text-[11px] text-slate-400">{language === 'ta' ? 'துறை & அறை' : 'Department & Room'}</div>
                  <div className="text-sm font-bold text-white mt-0.5">{activeToken.departmentName}</div>
                  <div className="text-xs text-brand-300">{activeToken.doctorRoom}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/80">
                  <div className="text-[11px] text-slate-400">{language === 'ta' ? 'மருத்துவர்' : 'Assigned Doctor'}</div>
                  <div className="text-sm font-bold text-white mt-0.5">{activeToken.doctorName}</div>
                  <div className="text-xs text-slate-300">{language === 'ta' ? 'சிறப்பு மருத்துவர்' : 'Specialist Consultation'}</div>
                </div>
              </div>

              {/* 3 Metric Pills: Ahead, Serving, AI Wait */}
              <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-1">
                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-center">
                  <div className="text-[10px] sm:text-xs text-slate-400">{t.patientsAhead}</div>
                  <div className="text-xl sm:text-2xl font-black text-amber-400 mt-0.5">
                    {activeToken.patientsAhead}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-center">
                  <div className="text-[10px] sm:text-xs text-slate-400">{t.currentServing}</div>
                  <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono mt-0.5">
                    {activeToken.currentServingToken}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-center">
                  <div className="text-[10px] sm:text-xs text-slate-400">{t.aiEstWait}</div>
                  <div className="text-xl sm:text-2xl font-black text-cyan-300 mt-0.5">
                    {activeToken.estimatedWaitMinutes} <span className="text-xs font-medium text-slate-400">{t.minutes}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onTrackQueue}
                  className="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center space-x-1.5"
                >
                  <Activity className="w-4 h-4" />
                  <span>{t.trackQueueLive}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onViewAIPrediction}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs sm:text-sm border border-slate-700 transition flex items-center space-x-1.5"
                >
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>{t.explainAi}</span>
                </button>

                {activeToken.estimatedWaitMinutes <= 15 && !activeToken.enRouteConfirmed && (
                  <button
                    onClick={() => markEnRoute(activeToken.id)}
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm shadow-sm transition flex items-center space-x-1.5"
                  >
                    <Car className="w-4 h-4" />
                    <span>{t.confirmReturn}</span>
                  </button>
                )}
              </div>

            </div>

            {/* Right Column: QR Code Card */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center p-6 bg-white rounded-2xl text-slate-900 shadow-lg text-center space-y-3">
              <div className="p-2 bg-slate-50 rounded-xl border border-slate-200">
                <QRCodeSVG 
                  value={`SMARTQUEUE-TOKEN:${activeToken.tokenNumber}|PATIENT:${activeToken.patientName}|HOSPITAL:${hospitalName}|DEPT:${activeToken.departmentName}`}
                  size={140}
                  level="M"
                />
              </div>
              <div className="text-center">
                <div className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                  {t.contactlessQrPass}
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {t.scanPassPrompt}
                </p>
              </div>
              <div className="w-full pt-1">
                <button
                  onClick={onTrackQueue}
                  className="w-full py-2 text-center text-xs font-bold text-brand-600 bg-brand-50 hover:bg-brand-100 rounded-lg transition"
                >
                  {t.trackQueueLive} →
                </button>
              </div>
            </div>

          </div>
        </div>
      ) : (
        /* Empty State: No Active Token */
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mx-auto">
            <QrCode className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              {language === 'ta' ? 'செயலில் உள்ள டோக்கன் இல்லை' : 'No Active Queue Token'}
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {language === 'ta' 
                ? 'தற்போது உங்களிடம் செயலில் உள்ள டோக்கன் எதுவும் இல்லை. புதிய டோக்கனைப் பெற கீழே அழுத்தவும்.'
                : 'You do not currently have an active OPD queue token. Select a doctor to generate a remote token now.'}
            </p>
          </div>
          <button
            onClick={onStartTokenGeneration}
            className="px-6 py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs sm:text-sm shadow-md transition inline-flex items-center space-x-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.getNewToken}</span>
          </button>
        </div>
      )}

      {/* 3. Fast Action Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Card 1: Token Generation Flow Guide */}
        <div 
          onClick={onStartTokenGeneration}
          className="p-5 rounded-2xl bg-white border border-slate-200 card-shadow hover:border-brand-300 cursor-pointer transition space-y-3"
        >
          <div className="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center">
            <Stethoscope className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">
            {language === 'ta' ? '5-படி டோக்கன் முன்பதிவு' : '5-Step Token Booking'}
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            {language === 'ta' 
              ? 'மருத்துவமனை → துறை → மருத்துவர் → வருகை வகை → டிஜிட்டல் டோக்கன்.'
              : 'Hospital Selection → Department Selection → Doctor Selection → Visit Type → Generate Token.'}
          </p>
          <div className="text-xs font-semibold text-brand-600 flex items-center pt-1">
            <span>{language === 'ta' ? 'புதிய டோக்கன் பெறுக' : 'Book New Appointment'}</span>
            <ArrowUpRight className="w-4 h-4 ml-1" />
          </div>
        </div>

        {/* Card 2: AI Waiting-Time Engine */}
        <div 
          onClick={onViewAIPrediction}
          className="p-5 rounded-2xl bg-white border border-slate-200 card-shadow hover:border-purple-300 cursor-pointer transition space-y-3"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">
            {t.aiPredictionTitle}
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            {language === 'ta'
              ? 'M/M/c வரிசை அல்காரிதம், 87% கணிப்பு துல்லியம் மற்றும் மருத்துவர் வேக காரணிகள்.'
              : 'Inspect our M/M/c queue algorithm, 87% prediction confidence, and live doctor speed factor.'}
          </p>
          <div className="text-xs font-semibold text-purple-600 flex items-center pt-1">
            <span>{t.explainAi}</span>
            <ArrowUpRight className="w-4 h-4 ml-1" />
          </div>
        </div>

        {/* Card 3: Patient History ("My Visits") */}
        <div 
          onClick={onViewVisits}
          className="p-5 rounded-2xl bg-white border border-slate-200 card-shadow hover:border-emerald-300 cursor-pointer transition space-y-3"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Calendar className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900">
            {language === 'ta' ? 'என் மருத்துவ வருகைகள்' : 'My Visits & Records'}
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            {language === 'ta'
              ? 'முந்தைய ஆலோசனைகள், காத்திருப்பு நேரங்கள் மற்றும் மருத்துவக் குறிப்புகள்.'
              : 'View past consultations (Cardiology Dr. Kumar, Lab Dr. Priya), wait times, and summaries.'}
          </p>
          <div className="text-xs font-semibold text-emerald-600 flex items-center pt-1">
            <span>{language === 'ta' ? 'வரலாற்றைக் காண்க' : 'View Medical History'}</span>
            <ArrowUpRight className="w-4 h-4 ml-1" />
          </div>
        </div>

      </div>

    </div>
  );
};
