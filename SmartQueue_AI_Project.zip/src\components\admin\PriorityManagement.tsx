import React, { useState } from 'react';
import { 
  Users, 
  AlertTriangle, 
  ArrowUp, 
  ArrowDown, 
  PhoneCall, 
  CheckCircle2, 
  AlertOctagon, 
  Sparkles, 
  Search,
  Filter,
  ShieldAlert
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { PriorityCategory, QueueToken } from '../../types/queue';

export const PriorityManagement: React.FC = () => {
  const { 
    tokens, 
    updatePatientPriority, 
    movePatientInQueue, 
    callNextToken,
    departments 
  } = useQueue();

  const [selectedDeptFilter, setSelectedDeptFilter] = useState('all');
  const [emergencyModalToken, setEmergencyModalToken] = useState<QueueToken | null>(null);

  const waitingTokens = tokens.filter(
    t => t.status === 'waiting' || t.status === 'approaching' || t.status === 'serving'
  );

  const filteredTokens = waitingTokens.filter(t => {
    if (selectedDeptFilter === 'all') return true;
    return t.departmentId === selectedDeptFilter;
  });

  const getPriorityBadge = (cat: PriorityCategory) => {
    switch (cat) {
      case 'emergency':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-red-600 text-white animate-pulse">EMERGENCY</span>;
      case 'senior':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">Senior Citizen (60+)</span>;
      case 'pregnant':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800">Pregnant Mother</span>;
      case 'pwd':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">PwD / Special Care</span>;
      case 'child':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-pink-100 text-pink-800">Child / Pediatric</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700">General</span>;
    }
  };

  const handleConfirmEmergency = () => {
    if (emergencyModalToken) {
      updatePatientPriority(emergencyModalToken.id, 'emergency', true);
      setEmergencyModalToken(null);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Info */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-brand-600" />
            <h2 className="text-xl font-extrabold text-slate-900">
              Patient Priority & Triage Management
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Administrative queue triage prototype. Staff can reorder queue positions, allocate senior/priority lanes, and flag urgent cases.
          </p>
        </div>

        {/* Department Filter */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-500">Department:</span>
          <select
            value={selectedDeptFilter}
            onChange={(e) => setSelectedDeptFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-white"
          >
            <option value="all">All Departments</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Priority Legend */}
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-wrap items-center gap-3 text-xs">
        <span className="font-bold text-slate-700">Triage Weighting:</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded bg-red-100 text-red-800 font-bold">🚨 Emergency (Score 100)</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">Senior Citizen (Score 80)</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-semibold">Pregnant (Score 75)</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-semibold">PwD (Score 75)</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded bg-pink-100 text-pink-800 font-semibold">Child (Score 65)</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded bg-slate-200 text-slate-700">General (Score 50)</span>
      </div>

      {/* Queue Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden card-shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-600 text-xs font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Token</th>
                <th className="py-3.5 px-4">Patient Details</th>
                <th className="py-3.5 px-4">Department & Doctor</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Status & Ahead</th>
                <th className="py-3.5 px-4">Priority Score</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredTokens.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 text-xs">
                    No active patients waiting in selected queue.
                  </td>
                </tr>
              ) : (
                filteredTokens.map((tok) => {
                  const isEmergency = tok.patientCategory === 'emergency' || tok.isEmergencyOverride;
                  return (
                    <tr 
                      key={tok.id} 
                      className={`transition ${isEmergency ? 'bg-red-50/60 font-semibold' : 'hover:bg-slate-50/80'}`}
                    >
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className={`font-mono text-base font-extrabold ${isEmergency ? 'text-red-700' : 'text-slate-900'}`}>
                          {tok.tokenNumber}
                        </span>
                        {tok.id === 'tok-c127' && (
                          <span className="block text-[10px] text-brand-600 font-bold uppercase">
                            (Rithika M)
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="text-slate-900 font-bold">{tok.patientName}</div>
                        <div className="text-[11px] text-slate-500">{tok.patientAge} yrs • {tok.patientPhone}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="text-slate-800">{tok.departmentName}</div>
                        <div className="text-[11px] text-brand-600">{tok.doctorName}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <select
                          value={tok.patientCategory}
                          onChange={(e) => updatePatientPriority(tok.id, e.target.value as PriorityCategory)}
                          className="px-2 py-1 rounded-lg border border-slate-300 text-xs bg-white font-semibold"
                        >
                          <option value="general">General</option>
                          <option value="senior">Senior Citizen</option>
                          <option value="pregnant">Pregnant</option>
                          <option value="child">Child</option>
                          <option value="pwd">PwD</option>
                          <option value="emergency">Emergency</option>
                        </select>
                      </td>

                      <td className="py-3.5 px-4">
                        {tok.status === 'serving' ? (
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                            Currently In Cabin
                          </span>
                        ) : (
                          <span className="text-slate-600">
                            <strong>{tok.patientsAhead}</strong> ahead (~{tok.estimatedWaitMinutes}m)
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-1.5">
                          <span className="font-bold text-slate-900">{tok.priorityScore}</span>
                          <button
                            onClick={() => movePatientInQueue(tok.id, 'up')}
                            className="p-1 rounded hover:bg-slate-200 text-slate-600"
                            title="Bump Up in Queue"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => movePatientInQueue(tok.id, 'down')}
                            className="p-1 rounded hover:bg-slate-200 text-slate-600"
                            title="Bump Down in Queue"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                        {!isEmergency && (
                          <button
                            onClick={() => setEmergencyModalToken(tok)}
                            className="px-2.5 py-1 text-xs font-bold rounded-lg bg-red-100 hover:bg-red-200 text-red-700 transition"
                          >
                            Mark Emergency
                          </button>
                        )}
                        <button
                          onClick={() => callNextToken(tok.departmentId)}
                          className="px-2.5 py-1 text-xs font-bold rounded-lg bg-brand-600 hover:bg-brand-700 text-white transition shadow-sm"
                        >
                          Call Next
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Safety Confirmation Dialog for Emergency Status Override */}
      {emergencyModalToken && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-red-200 space-y-4">
            
            <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-7 h-7" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-lg font-black text-slate-900">
                Confirm Emergency Queue Override
              </h3>
              <p className="text-xs text-slate-500">
                Are you sure you want to mark Token <strong className="text-red-600 font-mono">{emergencyModalToken.tokenNumber}</strong> ({emergencyModalToken.patientName}) as an <strong>Administrative Emergency Priority</strong>?
              </p>
            </div>

            {/* Disclaimer Callout */}
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
              <strong>Notice:</strong> This action updates administrative queue ordering to allocate immediate triage slots. It is an administrative queue-priority prototype and does not replace certified clinical triage protocol.
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <button
                onClick={() => setEmergencyModalToken(null)}
                className="w-1/2 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmEmergency}
                className="w-1/2 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md transition"
              >
                Confirm Emergency
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
