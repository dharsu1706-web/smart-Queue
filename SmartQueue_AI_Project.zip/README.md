# SmartQueue AI – Smart Hospital Queue Management System

> **“Don’t wait in the hospital — know when to return.”**
> Less Waiting • Less Crowding • Better Efficiency • Better Patient Experience

## Overview
SmartQueue AI is a full-stack, responsive hospital queue management web application designed to eliminate crowded waiting rooms with contactless QR digital tokens, live queue telemetry, M/M/c queueing AI wait prediction, smart return alerts, and administrative triage controls.

## Features
- **Landing Page**: Modern healthcare theme, remote waiting illustration, 4 core pillar cards, live department status board.
- **Patient Portal**:
  - 1-Click demo authentication as **Rithika M**.
  - Active Token Spotlight (**C-127**, Dr. Kumar Ramanathan, Cardiology).
  - 5-step token booking workflow with scannable QR pass.
  - Live Queue Radar with 4-stage pipeline (`Completed` → `Current` → `Your Token` → `Remaining`).
  - **AI Waiting-Time Prediction**: M/M/c algorithm calculating 42 min wait at 87% confidence, factoring in queue depth, doctor velocity, department workload, and historical patterns. Ready for Python/FastAPI ML model integration.
  - **Smart Return Now Alerts**: Proximity notification at 10 minutes with "Return Now" and "Snooze" actions.
  - **My Visits**: Consultation history with printable summaries.
- **Hospital Admin Dashboard**:
  - 6 KPI cards (Total Patients, Waiting, Served, Emergency, Avg Wait, Active Doctors).
  - Live Department Queue Panel (Cardiology, General Medicine, Orthopedics, Pediatrics, Neurology, Dermatology, Lab, Pharmacy, Billing).
  - Patient Priority Management (Emergency, Senior Citizen, Pregnant, Child, PwD, General) with safety confirmation dialog.
  - Doctor roster management & queue pausing/resuming.
  - 5-Stage Patient Flow Monitoring (Registration → Consultation → Lab → Pharmacy → Billing).
  - Real-time Analytics with 4 Recharts graphs and CSV/JSON report downloads.
  - Dedicated Emergency Queue view.
- **Waiting Room Kiosk**: Fullscreen high-contrast TV display for hospital halls.
- **Live Demo Simulator**: Floating evaluator controller to advance queue, auto-simulate, and test emergency triggers.

## Quick Start
```bash
# Run dev server
npm run dev

# Production build
npm run build
```

Application runs locally at: `http://localhost:3000`
