import React from 'react';
import { 
  X, 
  Bell, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Activity, 
  Trash2, 
  Navigation,
  Car
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { NotificationItem } from '../../types/queue';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTokenView?: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  onSelectTokenView
}) => {
  const { 
    notifications, 
    markNotificationRead, 
    clearAllNotifications,
    activeToken,
    markEnRoute
  } = useQueue();

  if (!isOpen) return null;

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'token_generated':
        return <CheckCircle2 className="w-5 h-5 text-emerald-500" />;
      case 'turn_approaching':
        return <Bell className="w-5 h-5 text-amber-500 animate-bounce" />;
      case 'your_turn':
        return <Activity className="w-5 h-5 text-red-500 animate-pulse" />;
      case 'emergency_priority_update':
        return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case 'waiting_time_changed':
        return <Clock className="w-5 h-5 text-blue-500" />;
      case 'doctor_delayed':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      default:
        return <Bell className="w-5 h-5 text-brand-500" />;
    }
  };

  const getUrgencyBadge = (urgency: NotificationItem['urgency']) => {
    switch (urgency) {
      case 'critical':
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-red-100 text-red-700 uppercase">Immediate</span>;
      case 'high':
        return <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-100 text-amber-700 uppercase">Action Required</span>;
      case 'normal':
        return <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-blue-100 text-blue-700">Update</span>;
      default:
        return <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-slate-100 text-slate-600">Info</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-slate-200">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl bg-brand-100 text-brand-700 flex items-center justify-center">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">Notification Center</h2>
                <p className="text-xs text-slate-500">Live queue alerts & return notifications</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {notifications.length > 0 && (
                <button
                  onClick={clearAllNotifications}
                  className="p-1.5 text-xs text-slate-400 hover:text-red-500 rounded-lg transition"
                  title="Clear all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick En-Route Reminder if Turn is Approaching */}
          {activeToken && (activeToken.status === 'approaching' || activeToken.estimatedWaitMinutes <= 15) && (
            <div className="bg-amber-50 border-b border-amber-200 p-4">
              <div className="flex items-start space-x-3">
                <Car className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <h4 className="text-xs font-bold text-amber-900">Estimated turn: ~{activeToken.estimatedWaitMinutes} mins</h4>
                  <p className="text-[11px] text-amber-700 mt-0.5">
                    Avoid hospital lobby overcrowding. Start returning now to arrive right on time!
                  </p>
                  {!activeToken.enRouteConfirmed ? (
                    <button
                      onClick={() => activeToken && markEnRoute(activeToken.id)}
                      className="mt-2 inline-flex items-center px-2.5 py-1 text-xs font-bold rounded-md bg-amber-600 text-white hover:bg-amber-700 transition shadow-sm"
                    >
                      <Navigation className="w-3.5 h-3.5 mr-1" />
                      I am Returning Now
                    </button>
                  ) : (
                    <span className="mt-2 inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded bg-emerald-100 text-emerald-800">
                      ✓ Reception notified you are en route
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Notification List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-3 space-y-2">
            {notifications.length === 0 ? (
              <div className="text-center py-16 px-4">
                <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h3 className="text-sm font-semibold text-slate-700">No new notifications</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Live updates regarding your token and doctor status will appear here.
                </p>
              </div>
            ) : (
              notifications.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => markNotificationRead(notif.id)}
                  className={`p-3.5 rounded-xl border transition cursor-pointer ${
                    notif.read 
                      ? 'bg-white border-slate-100 opacity-80' 
                      : 'bg-brand-50/50 border-brand-100 shadow-sm'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="mt-0.5 shrink-0">{getNotificationIcon(notif.type)}</div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="text-xs font-bold text-slate-900">{notif.title}</h4>
                          {getUrgencyBadge(notif.urgency)}
                        </div>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {notif.message}
                        </p>
                        <div className="flex items-center justify-between mt-2 pt-1">
                          <span className="text-[10px] text-slate-400">{notif.timestamp}</span>
                          {notif.tokenNumber && onSelectTokenView && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectTokenView();
                                onClose();
                              }}
                              className="text-[11px] font-semibold text-brand-600 hover:text-brand-700"
                            >
                              Track {notif.tokenNumber} →
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-3 border-t border-slate-200 bg-slate-50 text-center">
            <p className="text-[11px] text-slate-500">
              SmartQueue AI notification service • Push & SMS enabled
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
