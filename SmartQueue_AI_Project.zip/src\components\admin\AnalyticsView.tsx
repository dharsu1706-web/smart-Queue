import React from 'react';
import { 
  BarChart, 
  Bar, 
  AreaChart, 
  Area, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { 
  BarChart3, 
  Download, 
  TrendingUp, 
  Clock, 
  Users, 
  Activity, 
  CheckCircle2, 
  Sparkles,
  FileSpreadsheet
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { 
  HOURLY_PATIENT_VOLUME, 
  WAITING_TIME_COMPARISON, 
  DEPARTMENT_WORKLOAD_DISTRIBUTION, 
  QUEUE_LENGTH_TREND 
} from '../../data/mockData';
import { exportQueueReportToCSV, exportAnalyticsSummaryJSON } from '../../services/exportService';

export const AnalyticsView: React.FC = () => {
  const { tokens, hospitalName } = useQueue();

  const handleDownloadCSV = () => {
    exportQueueReportToCSV(tokens, hospitalName);
  };

  const handleDownloadJSON = () => {
    exportAnalyticsSummaryJSON({
      hospital: hospitalName,
      generatedAt: new Date().toISOString(),
      dailyVolume: HOURLY_PATIENT_VOLUME,
      waitingTimeComparison: WAITING_TIME_COMPARISON,
      workloadDistribution: DEPARTMENT_WORKLOAD_DISTRIBUTION,
      activeTokensCount: tokens.length
    });
  };

  return (
    <div className="space-y-8">
      
      {/* 1. Header with Download Report Action */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-brand-600" />
            <h2 className="text-xl font-extrabold text-slate-900">
              Queue Analytics & Performance Intelligence
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time telemetry, waiting trends, and comparative metrics for {hospitalName}.
          </p>
        </div>

        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <button
            onClick={handleDownloadCSV}
            className="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-md transition flex items-center space-x-2 active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download Report (CSV)</span>
          </button>
          <button
            onClick={handleDownloadJSON}
            className="px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
            title="Export JSON telemetry"
          >
            <FileSpreadsheet className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Key Performance Indicators Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <div className="text-xs text-slate-500">Average Waiting Time</div>
          <div className="text-2xl font-black text-brand-600 mt-1">18 min</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">
            ↓ 46% vs Conventional OPD
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <div className="text-xs text-slate-500">Total Served Today</div>
          <div className="text-2xl font-black text-slate-900 mt-1">232</div>
          <div className="text-[11px] text-slate-400 mt-1">
            +18% throughput efficiency
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <div className="text-xs text-slate-500">Average Consultation</div>
          <div className="text-2xl font-black text-slate-900 mt-1">11.4 min</div>
          <div className="text-[11px] text-slate-400 mt-1">
            Across 9 departments
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
          <div className="text-xs text-slate-500">Lobby Congestion Reduction</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">-58%</div>
          <div className="text-[11px] text-emerald-700 font-semibold mt-1">
            Patients waiting remotely
          </div>
        </div>
      </div>

      {/* 3. Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Daily Patient Volume (Area Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              1. Daily Patient Volume by Hour
            </h3>
            <p className="text-[11px] text-slate-500">
              SmartQueue remote check-ins vs walk-in reception registrations
            </p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={HOURLY_PATIENT_VOLUME}>
                <defs>
                  <linearGradient id="colorSmart" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Area type="monotone" dataKey="smartQueue" name="SmartQueue Remote" stroke="#2563eb" fillOpacity={1} fill="url(#colorSmart)" />
                <Area type="monotone" dataKey="walkIn" name="Walk-In Physical" stroke="#94a3b8" fill="#e2e8f0" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Average Waiting Time Comparison (Bar Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              2. Waiting Time Comparison (Minutes)
            </h3>
            <p className="text-[11px] text-slate-500">
              Traditional hospital queue vs SmartQueue AI remote pacing
            </p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={WAITING_TIME_COMPARISON}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="department" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="traditional" name="Traditional (Min)" fill="#ef4444" radius={[4, 4, 0, 0]} />
                <Bar dataKey="smartQueue" name="SmartQueue (Min)" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Department Workload Distribution (Donut / Pie Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              3. Department Workload Distribution (%)
            </h3>
            <p className="text-[11px] text-slate-500">
              Share of outpatient consultations by department
            </p>
          </div>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={DEPARTMENT_WORKLOAD_DISTRIBUTION}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {DEPARTMENT_WORKLOAD_DISTRIBUTION.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Queue Length & Wait Trends Over Time (Line Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 card-shadow space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              4. Peak-Hour Queue Length & Waiting Trends
            </h3>
            <p className="text-[11px] text-slate-500">
              Real-time correlation between OPD queue volume and average wait
            </p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={QUEUE_LENGTH_TREND}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="activeQueue" name="Active Queue (Patients)" stroke="#8b5cf6" strokeWidth={2} />
                <Line type="monotone" dataKey="waitTime" name="Predicted Wait (Min)" stroke="#f59e0b" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};
