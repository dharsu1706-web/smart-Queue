import React, { useState } from 'react';
import { 
  Building2, 
  Lock, 
  Mail, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles,
  KeyRound
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';

interface AdminAuthProps {
  onSuccess: () => void;
  onSwitchToPatient: () => void;
}

export const AdminAuth: React.FC<AdminAuthProps> = ({
  onSuccess,
  onSwitchToPatient
}) => {
  const { hospitalName } = useQueue();
  const [hospitalId, setHospitalId] = useState('CITYCARE-01');
  const [adminEmail, setAdminEmail] = useState('admin@citycare.org');
  const [password, setPassword] = useState('••••••••');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onSuccess();
  };

  const handleQuickDemoLogin = () => {
    setHospitalId('CITYCARE-01');
    setAdminEmail('admin@citycare.org');
    onSuccess();
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-slate-900">
      <div className="max-w-md w-full bg-slate-800/90 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-700 p-6 sm:p-8 space-y-6 text-white">
        
        {/* Header */}
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-xl bg-brand-500/20 text-brand-400 border border-brand-500/30 flex items-center justify-center mx-auto mb-3">
            <Building2 className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold text-white">
            Hospital Admin Portal
          </h2>
          <p className="text-xs text-slate-400">
            Secure access for hospital administrators, triage nurses, and OPD clinicians.
          </p>
        </div>

        {/* 1-Click Demo Login */}
        <div className="p-3.5 rounded-xl bg-slate-700/60 border border-slate-600">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold text-brand-300 uppercase tracking-wider flex items-center">
                <Sparkles className="w-3 h-3 mr-1 text-brand-400" /> Evaluation Mode
              </span>
              <p className="text-xs font-semibold text-slate-200">
                Log in as <strong>{hospitalName} Admin</strong>
              </p>
            </div>
            <button
              type="button"
              onClick={handleQuickDemoLogin}
              className="px-3 py-1.5 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-xs font-bold transition active:scale-95 shadow-md"
            >
              Quick Login
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Hospital ID
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <Building2 className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={hospitalId}
                onChange={(e) => setHospitalId(e.target.value)}
                placeholder="e.g. CITYCARE-01"
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Admin Email
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <Mail className="w-4 h-4" />
              </div>
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="admin@hospital.org"
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-brand-600/30 transition active:scale-95 flex items-center justify-center space-x-2"
          >
            <span>Enter OPD Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center pt-2 border-t border-slate-700">
          <button
            type="button"
            onClick={onSwitchToPatient}
            className="text-xs text-slate-400 hover:text-brand-300 transition"
          >
            Looking for Patient Portal? <strong>Switch to Patient View →</strong>
          </button>
        </div>

      </div>
    </div>
  );
};
