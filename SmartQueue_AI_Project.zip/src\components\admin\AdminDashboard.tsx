import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  Clock, 
  CheckCircle2, 
  AlertOctagon, 
  Stethoscope, 
  Activity, 
  BarChart3, 
  Layers, 
  ShieldAlert, 
  PhoneCall, 
  Pause, 
  Play, 
  FastForward,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { PriorityManagement } from './PriorityManagement';
import { DoctorDeptControl } from './DoctorDeptControl';
import { PatientFlowMonitor } from './PatientFlowMonitor';
import { AnalyticsView } from './AnalyticsView';
import { EmergencyQueueView } from './EmergencyQueueView';

type AdminTab = 
  | 'overview' 
  | 'priority' 
  | 'doctors_dept' 
  | 'flow' 
  | 'analytics' 
  | 'emergency';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const { 
    hospitalName, 
    departments, 
    doctors, 
    tokens, 
    callNextToken,
    pauseResumeQueue 
  } = useQueue();

  // Compute live KPIs
  const totalWaitingCount = tokens.filter(t => t.status === 'waiting' || t.status === 'approaching').length;
  const emergencyCount = tokens.filter(t => t.patientCategory === 'emergency' || t.isEmergencyOverride).length;
  const activeDoctorsCount = doctors.filter(d => d.status !== 'offline').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* 1. Hospital Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="space-y-2 relative z-10">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-xs uppercase font-extrabold tracking-wider text-brand-300">
              Hospital OPD Control Center
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            {hospitalName}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Real-time multi-department queue coordination, smart triage pacing, and AI wait telemetry.
          </p>
        </div>

        {/* Quick Triage Status */}
        <div className="flex items-center space-x-3 relative z-10 self-start md:self-auto">
          <div className="px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-center">
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Lobby Status</div>
            <div className="text-sm font-bold text-emerald-400 flex items-center justify-center mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5"></span>
              Controlled (Remote Pacing)
            </div>
          </div>
        </div>
      </div>

      {/* 2. Top-Level Tab Navigation */}
      <div className="flex items-center space-x-2 border-b border-slate-200 overflow-x-auto pb-2 text-xs sm:text-sm font-bold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition flex items-center space-x-2 ${
            activeTab === 'overview' 
              ? 'bg-brand-600 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Live Queue Operations</span>
        </button>

        <button
          onClick={() => setActiveTab('priority')}
          className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition flex items-center space-x-2 ${
            activeTab === 'priority' 
              ? 'bg-brand-600 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Patient Priority & Triage</span>
        </button>

        <button
          onClick={() => setActiveTab('doctors_dept')}
          className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition flex items-center space-x-2 ${
            activeTab === 'doctors_dept' 
              ? 'bg-brand-600 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Doctors & Departments</span>
        </button>

        <button
          onClick={() => setActiveTab('flow')}
          className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition flex items-center space-x-2 ${
            activeTab === 'flow' 
              ? 'bg-brand-600 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>5-Stage Patient Flow</span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition flex items-center space-x-2 ${
            activeTab === 'analytics' 
              ? 'bg-brand-600 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Analytics & Reports</span>
        </button>

        <button
          onClick={() => setActiveTab('emergency')}
          className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition flex items-center space-x-2 ${
            activeTab === 'emergency' 
              ? 'bg-red-600 text-white shadow-md' 
              : 'text-red-600 hover:bg-red-50'
          }`}
        >
          <AlertOctagon className="w-4 h-4" />
          <span>Emergency Queue ({emergencyCount})</span>
        </button>
      </div>

      {/* 3. Tab Contents */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          
          {/* KPI Cards Row (from Section 11 of Prompt) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            
            <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
              <div className="text-[11px] font-semibold text-slate-500">Total Patients Today</div>
              <div className="text-2xl font-black text-slate-900 mt-1">284</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Recorded OPD footfall</div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
              <div className="text-[11px] font-semibold text-slate-500">Patients Waiting</div>
              <div className="text-2xl font-black text-amber-600 mt-1">{totalWaitingCount || 46}</div>
              <div className="text-[10px] text-amber-700 font-medium mt-0.5">Active queue backlog</div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
              <div className="text-[11px] font-semibold text-slate-500">Patients Served</div>
              <div className="text-2xl font-black text-emerald-600 mt-1">238</div>
              <div className="text-[10px] text-emerald-700 font-medium mt-0.5">Consultations completed</div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
              <div className="text-[11px] font-semibold text-slate-500">Emergency Patients</div>
              <div className="text-2xl font-black text-red-600 mt-1">{emergencyCount || 6}</div>
              <div className="text-[10px] text-red-700 font-medium mt-0.5">Priority lane allocated</div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
              <div className="text-[11px] font-semibold text-slate-500">Avg Waiting Time</div>
              <div className="text-2xl font-black text-brand-600 mt-1">18 min</div>
              <div className="text-[10px] text-brand-700 font-medium mt-0.5">↓ 35% vs baseline</div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 card-shadow">
              <div className="text-[11px] font-semibold text-slate-500">Active Doctors</div>
              <div className="text-2xl font-black text-purple-600 mt-1">{activeDoctorsCount}/16</div>
              <div className="text-[10px] text-purple-700 font-medium mt-0.5">Consultants in OPD</div>
            </div>

          </div>

          {/* Live Queue Panel (from Section 11 of Prompt) */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden card-shadow">
            <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/70">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">
                  Live Department Queue Panel
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Department | Doctor | Current Token | Waiting | Status
                </p>
              </div>

              <div className="text-xs text-slate-500 flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Live OPD sync</span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-600 text-xs font-bold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-3.5 px-4 sm:px-6">Department</th>
                    <th className="py-3.5 px-4 sm:px-6">Attending Doctor</th>
                    <th className="py-3.5 px-4 sm:px-6">Current Token</th>
                    <th className="py-3.5 px-4 sm:px-6">Waiting</th>
                    <th className="py-3.5 px-4 sm:px-6">Status</th>
                    <th className="py-3.5 px-4 sm:px-6 text-right">Quick Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {departments.map((dept) => {
                    const assignedDoc = doctors.find(d => d.departmentId === dept.id);
                    return (
                      <tr key={dept.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-4 px-4 sm:px-6">
                          <div className="font-bold text-slate-900">{dept.name}</div>
                          <span className="text-[10px] font-mono text-slate-400 uppercase">Code: {dept.code}</span>
                        </td>

                        <td className="py-4 px-4 sm:px-6">
                          <div className="text-slate-800 font-semibold">{assignedDoc?.name || 'Assigned Duty Clinician'}</div>
                          <div className="text-[11px] text-brand-600">{assignedDoc?.room || 'Cabin OPD'}</div>
                        </td>

                        <td className="py-4 px-4 sm:px-6">
                          <span className="font-mono text-lg font-black text-emerald-600">
                            {dept.currentServingToken}
                          </span>
                        </td>

                        <td className="py-4 px-4 sm:px-6">
                          <span className="text-base font-bold text-slate-800">{dept.totalWaiting}</span>
                          <span className="text-xs text-slate-400 ml-1">(~{dept.avgWaitMinutes}m)</span>
                        </td>

                        <td className="py-4 px-4 sm:px-6">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold capitalize ${
                            dept.status === 'busy' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {dept.status === 'busy' ? 'Busy' : 'Active'}
                          </span>
                        </td>

                        <td className="py-4 px-4 sm:px-6 text-right space-x-2">
                          <button
                            onClick={() => callNextToken(dept.id)}
                            className="px-3 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-sm transition active:scale-95 inline-flex items-center space-x-1"
                          >
                            <FastForward className="w-3.5 h-3.5" />
                            <span>Call Next</span>
                          </button>

                          <button
                            onClick={() => pauseResumeQueue(dept.id, dept.status !== 'busy')}
                            className="px-2.5 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold"
                            title="Pause / Resume"
                          >
                            {dept.status === 'busy' ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {activeTab === 'priority' && <PriorityManagement />}
      {activeTab === 'doctors_dept' && <DoctorDeptControl />}
      {activeTab === 'flow' && <PatientFlowMonitor />}
      {activeTab === 'analytics' && <AnalyticsView />}
      {activeTab === 'emergency' && <EmergencyQueueView />}

    </div>
  );
};
