import { QueueToken } from '../types/queue';

export function exportQueueReportToCSV(tokens: QueueToken[], hospitalName: string) {
  const headers = [
    'Token Number',
    'Patient Name',
    'Department',
    'Doctor',
    'Priority Category',
    'Visit Type',
    'Est. Wait (Min)',
    'Status',
    'Generated Time'
  ];

  const rows = tokens.map(t => [
    t.tokenNumber,
    `"${t.patientName}"`,
    `"${t.departmentName}"`,
    `"${t.doctorName}"`,
    t.patientCategory.toUpperCase(),
    t.visitType,
    t.estimatedWaitMinutes,
    t.status,
    new Date(t.generatedAt).toLocaleTimeString()
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + 
    [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `SmartQueue_Report_${hospitalName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportAnalyticsSummaryJSON(stats: Record<string, unknown>) {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(stats, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `SmartQueue_Analytics_${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.removeChild(downloadAnchor);
}
