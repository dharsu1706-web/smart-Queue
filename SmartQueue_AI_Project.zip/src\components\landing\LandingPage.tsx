import React from 'react';
import { 
  Activity, 
  Clock, 
  Smartphone, 
  Bell, 
  BrainCircuit, 
  QrCode, 
  ShieldCheck, 
  Users, 
  ChevronRight, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  Building2,
  Stethoscope,
  HeartPulse,
  Timer,
  Navigation
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { useLanguage } from '../../context/LanguageContext';

interface LandingPageProps {
  onGetToken: () => void;
  onHospitalLogin: () => void;
  onViewLiveQueue: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetToken,
  onHospitalLogin,
  onViewLiveQueue
}) => {
  const { hospitalName, departments } = useQueue();
  const { t, language } = useLanguage();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-16 lg:pb-28 bg-gradient-to-b from-brand-50/70 via-white to-slate-50">
        
        {/* Subtle decorative grid/circles */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full overflow-hidden pointer-events-none -z-10">
          <div className="absolute -top-32 left-1/4 w-96 h-96 bg-brand-200/40 rounded-full blur-3xl" />
          <div className="absolute top-20 right-10 w-96 h-96 bg-cyan-200/30 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Headline & CTAs */}
            <div className="lg:col-span-7 text-center lg:text-left space-y-6">
              
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-brand-100/80 border border-brand-200 text-brand-800 text-xs font-semibold tracking-wide">
                <BrainCircuit className="w-3.5 h-3.5 text-brand-600 animate-pulse" />
                <span>{language === 'ta' ? 'அதிநவீன AI மருத்துவமனை வரிசை கட்டமைப்பு' : 'Next-Gen AI Hospital Queue Architecture'}</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
                {t.heroTitle1}{' '}
                <span className="bg-gradient-to-r from-brand-600 via-brand-700 to-cyan-600 bg-clip-text text-transparent">
                  {t.heroTitleHighlight}
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                {t.heroSubtitle}
              </p>

              {/* USP Banner */}
              <div className="p-3.5 rounded-xl bg-emerald-50/80 border border-emerald-200/90 text-xs sm:text-sm text-emerald-900 font-medium flex items-center space-x-2.5 max-w-xl mx-auto lg:mx-0">
                <Sparkles className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>
                  <strong>{language === 'ta' ? 'முதன்மைக் கோட்பாடு:' : 'Main Concept:'}</strong> {t.uspConcept}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={onGetToken}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-brand-600 to-brand-700 hover:from-brand-700 hover:to-brand-800 text-white font-bold text-base shadow-lg shadow-brand-500/25 transition-all transform active:scale-95 flex items-center justify-center space-x-2.5"
                >
                  <QrCode className="w-5 h-5" />
                  <span>{t.getTokenBtn}</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>

                <button
                  onClick={onHospitalLogin}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-bold text-base border border-slate-300 shadow-sm transition active:scale-95 flex items-center justify-center space-x-2"
                >
                  <Building2 className="w-5 h-5 text-slate-600" />
                  <span>{t.hospitalLoginBtn}</span>
                </button>
              </div>

              {/* 4 Outcome Pills */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 text-xs font-semibold text-slate-700 pt-3">
                <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700">{t.lessWaiting}</span>
                <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700">{t.lessCrowding}</span>
                <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700">{t.betterEfficiency}</span>
                <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700">{t.betterExperience}</span>
              </div>

            </div>

            {/* Right Column: Modern Remote Waiting Illustration & Preview */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md">
                
                {/* Visual Concept Comparison Card */}
                <div className="bg-white rounded-2xl p-5 shadow-2xl border border-slate-200/90 relative z-10 space-y-4">
                  
                  {/* Top Header of Simulated Phone */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-lg bg-brand-600 text-white flex items-center justify-center">
                        <Activity className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">{hospitalName}</div>
                        <div className="text-[10px] text-emerald-600 font-semibold flex items-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1 animate-ping"></span>
                          {language === 'ta' ? 'தொலைநிலைக் கண்காணிப்பு இயங்குகிறது' : 'Remote Tracking Active'}
                        </div>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-brand-50 text-brand-700">
                      TOKEN: C-127
                    </span>
                  </div>

                  {/* Remote Patient Waiting vs Crowded OPD Graphic */}
                  <div className="relative rounded-xl overflow-hidden bg-slate-900 text-white p-4">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500/20 rounded-full blur-2xl pointer-events-none"></div>
                    <div className="text-[11px] uppercase tracking-wider text-brand-400 font-semibold">
                      {language === 'ta' ? 'தொலைவில் காத்திருப்பு (வீடு / காபி ஷாப்)' : 'Waiting Remotely (Café / Home)'}
                    </div>
                    <div className="mt-2 flex items-baseline space-x-2">
                      <span className="text-3xl font-extrabold text-white">42</span>
                      <span className="text-xs text-slate-300">{language === 'ta' ? 'நிமிடங்கள் மீதம்' : 'minutes remaining'}</span>
                    </div>
                    
                    {/* Live Progress Bar */}
                    <div className="mt-3 space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>{t.patientsAhead}: <strong>8</strong></span>
                        <span>{t.currentServing}: <strong>C-119</strong></span>
                      </div>
                      <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-emerald-500 to-brand-500 w-3/5 rounded-full"></div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-800 text-[11px] text-slate-300 flex items-center space-x-1.5">
                      <Navigation className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{language === 'ta' ? '10 நிமிடத்திற்கு முன் எச்சரிக்கை ஒலிக்கும்' : 'Smart Alert will sound at 10 minutes'}</span>
                    </div>
                  </div>

                  {/* Notification Preview Card */}
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start space-x-3">
                    <Bell className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 animate-bounce" />
                    <div>
                      <div className="text-xs font-bold">{t.smartNotifTitle}</div>
                      <p className="text-[11px] text-amber-700 mt-0.5">
                        {t.returnNowMsg}
                      </p>
                    </div>
                  </div>

                  {/* Interactive Button to Jump to Tracker */}
                  <button
                    onClick={onViewLiveQueue}
                    className="w-full py-2.5 text-center text-xs font-bold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                  >
                    {t.trackQueueLive} →
                  </button>

                </div>

                {/* Decorative background glow */}
                <div className="absolute -bottom-6 -left-6 -right-6 h-40 bg-gradient-to-r from-brand-600 to-cyan-500 opacity-20 rounded-3xl blur-2xl -z-0"></div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Highlight Cards Section */}
      <section id="features" className="py-16 bg-white border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-xs font-bold uppercase tracking-wider text-brand-600 mb-2">
              {language === 'ta' ? '4 முக்கிய தூண்கள்' : 'Four Core Pillars'}
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900">
              {language === 'ta' ? 'மருத்துவமனை நெரிசலை அகற்ற வடிவமைக்கப்பட்டது' : 'Engineered to Eliminate Hospital Bottlenecks'}
            </h3>
            <p className="text-slate-600 text-sm sm:text-base mt-2">
              {language === 'ta' 
                ? 'முன்கணிப்பு நுண்ணறிவு மற்றும் காண்டாக்ட்லெஸ் டிஜிட்டல் டோக்கன்களை இணைத்து தினசரி நேரத்தை மிச்சப்படுத்துகிறது.'
                : 'Combining predictive intelligence with contactless digital tokens so patients and clinicians save hours every single day.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Card 1: Digital Token */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-brand-300 card-shadow-hover space-y-3">
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-brand-600 flex items-center justify-center">
                <QrCode className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">{t.digitalTokenTitle}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{t.digitalTokenDesc}</p>
              <div className="pt-2 text-xs font-semibold text-brand-600 flex items-center">
                <span>{language === 'ta' ? 'உடனடி QR உருவாக்கம்' : 'Instant QR generation'}</span>
                <ChevronRight className="w-4 h-4 ml-0.5" />
              </div>
            </div>

            {/* Card 2: Real-Time Queue Tracking */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-brand-300 card-shadow-hover space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <Clock className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">{t.realtimeTrackingTitle}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{t.realtimeTrackingDesc}</p>
              <div className="pt-2 text-xs font-semibold text-emerald-600 flex items-center">
                <span>{language === 'ta' ? 'நேரலை நிலவரம்' : 'Live status updates'}</span>
                <ChevronRight className="w-4 h-4 ml-0.5" />
              </div>
            </div>

            {/* Card 3: AI Waiting-Time Prediction */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-brand-300 card-shadow-hover space-y-3">
              <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
                <BrainCircuit className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">{t.aiPredictionTitle}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{t.aiPredictionDesc}</p>
              <div className="pt-2 text-xs font-semibold text-purple-600 flex items-center">
                <span>{language === 'ta' ? 'துல்லியமான ML மாடல்' : 'Predictive ML model'}</span>
                <ChevronRight className="w-4 h-4 ml-0.5" />
              </div>
            </div>

            {/* Card 4: Smart Notifications */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-brand-300 card-shadow-hover space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
                <Bell className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">{t.smartNotifTitle}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{t.smartNotifDesc}</p>
              <div className="pt-2 text-xs font-semibold text-amber-600 flex items-center">
                <span>{language === 'ta' ? 'SMS & ஆப் அறிவிப்புகள்' : 'SMS & In-app alerts'}</span>
                <ChevronRight className="w-4 h-4 ml-0.5" />
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 3. Live Hospital Department Ticker */}
      <section className="py-12 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                <h3 className="text-lg font-bold">{language === 'ta' ? 'நேரலை புறநோயாளிகள் துறை நிலவரம்' : 'Live OPD Department Status'}</h3>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {hospitalName}
              </p>
            </div>
            <button
              onClick={onGetToken}
              className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs transition self-start md:self-auto"
            >
              {t.getTokenBtn} →
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 mt-6">
            {departments.slice(0, 6).map((dept) => (
              <div key={dept.id} className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200 truncate">{dept.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700 text-brand-300 font-mono font-bold">
                    {dept.code}
                  </span>
                </div>
                <div className="text-xl font-extrabold text-white">
                  {dept.avgWaitMinutes} <span className="text-xs font-normal text-slate-400">{t.minutes}</span>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>{t.currentServing}: <strong className="text-emerald-400 font-mono">{dept.currentServingToken}</strong></span>
                  <span className="text-slate-500">{dept.totalWaiting} wait</span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 4. Footer */}
      <footer id="about" className="bg-slate-950 text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-2">
          <div className="flex items-center justify-center space-x-2 text-white font-bold text-lg">
            <Activity className="w-5 h-5 text-brand-500" />
            <span>{t.appName}</span>
          </div>
          <p className="text-xs text-slate-400">
            {t.tagline} • {t.uspConcept}
          </p>
          <div className="text-xs text-slate-500 pt-2">
            © 2026 SmartQueue AI. தமிழ் & English Multi-language Support Enabled.
          </div>
        </div>
      </footer>

    </div>
  );
};
