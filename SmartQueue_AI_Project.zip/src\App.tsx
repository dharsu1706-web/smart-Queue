import React, { useState } from 'react';
import { QueueProvider, useQueue } from './context/QueueContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Navbar } from './components/common/Navbar';
import { NotificationCenter } from './components/common/NotificationCenter';
import { DemoController } from './components/common/DemoController';
import { LandingPage } from './components/landing/LandingPage';
import { PatientAuth } from './components/patient/PatientAuth';
import { PatientDashboard } from './components/patient/PatientDashboard';
import { TokenGenerator } from './components/patient/TokenGenerator';
import { LiveQueueTracker } from './components/patient/LiveQueueTracker';
import { AIPredictionCard } from './components/patient/AIPredictionCard';
import { SmartReturnNotificationModal } from './components/patient/SmartReturnNotification';
import { MyVisits } from './components/patient/MyVisits';
import { AdminAuth } from './components/admin/AdminAuth';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { WaitingRoomKiosk } from './components/kiosk/WaitingRoomKiosk';

type AppView = 'landing' | 'patient' | 'admin' | 'kiosk' | 'auth-patient' | 'auth-admin';
type PatientSubView = 'dashboard' | 'generate' | 'tracker' | 'ai' | 'visits';

const MainAppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [patientSubView, setPatientSubView] = useState<PatientSubView>('dashboard');
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [returnModalOpen, setReturnModalOpen] = useState(false);

  const { activeToken } = useQueue();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* 1. Navbar (Hidden in Fullscreen Kiosk Mode) */}
      {currentView !== 'kiosk' && (
        <Navbar
          currentView={currentView}
          setCurrentView={(v) => {
            setCurrentView(v);
            if (v === 'patient') setPatientSubView('dashboard');
          }}
          onOpenNotifications={() => setNotificationsOpen(true)}
        />
      )}

      {/* 2. Secondary Patient Sub-nav if in Patient Mode */}
      {currentView === 'patient' && (
        <div className="bg-white border-b border-slate-200 sticky top-16 z-30 shadow-xs">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center space-x-2 sm:space-x-4 py-2.5 overflow-x-auto text-xs font-bold">
              <button
                onClick={() => setPatientSubView('dashboard')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition ${
                  patientSubView === 'dashboard' 
                    ? 'bg-brand-50 text-brand-700 font-extrabold border border-brand-200' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t.home}
              </button>

              <button
                onClick={() => setPatientSubView('generate')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition ${
                  patientSubView === 'generate' 
                    ? 'bg-brand-50 text-brand-700 font-extrabold border border-brand-200' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t.getNewToken}
              </button>

              <button
                onClick={() => setPatientSubView('tracker')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition flex items-center space-x-1.5 ${
                  patientSubView === 'tracker' 
                    ? 'bg-brand-50 text-brand-700 font-extrabold border border-brand-200' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>{t.trackQueueLive}</span>
                {activeToken && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                )}
              </button>

              <button
                onClick={() => setPatientSubView('ai')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition ${
                  patientSubView === 'ai' 
                    ? 'bg-purple-50 text-purple-700 font-extrabold border border-purple-200' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t.explainAi}
              </button>

              <button
                onClick={() => setPatientSubView('visits')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition ${
                  patientSubView === 'visits' 
                    ? 'bg-brand-50 text-brand-700 font-extrabold border border-brand-200' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                My Visits
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Main Body Content Based on Active View */}
      <main className="flex-1">
        
        {/* Landing Page */}
        {currentView === 'landing' && (
          <LandingPage
            onGetToken={() => {
              setCurrentView('patient');
              setPatientSubView('generate');
            }}
            onHospitalLogin={() => setCurrentView('auth-admin')}
            onViewLiveQueue={() => {
              setCurrentView('patient');
              setPatientSubView('tracker');
            }}
          />
        )}

        {/* Patient Authentication */}
        {currentView === 'auth-patient' && (
          <PatientAuth
            onSuccess={() => {
              setCurrentView('patient');
              setPatientSubView('dashboard');
            }}
            onSwitchToAdmin={() => setCurrentView('auth-admin')}
          />
        )}

        {/* Patient Portal Subviews */}
        {currentView === 'patient' && (
          <div>
            {patientSubView === 'dashboard' && (
              <PatientDashboard
                onStartTokenGeneration={() => setPatientSubView('generate')}
                onTrackQueue={() => setPatientSubView('tracker')}
                onViewVisits={() => setPatientSubView('visits')}
                onViewAIPrediction={() => setPatientSubView('ai')}
              />
            )}

            {patientSubView === 'generate' && (
              <TokenGenerator
                onTokenGenerated={() => setPatientSubView('tracker')}
                onTrackQueue={() => setPatientSubView('tracker')}
                onCancel={() => setPatientSubView('dashboard')}
              />
            )}

            {patientSubView === 'tracker' && (
              <LiveQueueTracker
                onViewAIPrediction={() => setPatientSubView('ai')}
                onViewReturnModal={() => setReturnModalOpen(true)}
                onBookAnotherToken={() => setPatientSubView('generate')}
              />
            )}

            {patientSubView === 'ai' && <AIPredictionCard />}

            {patientSubView === 'visits' && <MyVisits />}
          </div>
        )}

        {/* Hospital Admin Authentication */}
        {currentView === 'auth-admin' && (
          <AdminAuth
            onSuccess={() => setCurrentView('admin')}
            onSwitchToPatient={() => setCurrentView('patient')}
          />
        )}

        {/* Hospital Admin Dashboard */}
        {currentView === 'admin' && <AdminDashboard />}

        {/* Fullscreen Waiting Hall Display Kiosk */}
        {currentView === 'kiosk' && (
          <WaitingRoomKiosk onBackToApp={() => setCurrentView('landing')} />
        )}

      </main>

      {/* 4. Slide-Over Notification Drawer */}
      <NotificationCenter
        isOpen={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        onSelectTokenView={() => {
          setCurrentView('patient');
          setPatientSubView('tracker');
        }}
      />

      {/* 5. Smart Return Now Notification Modal */}
      <SmartReturnNotificationModal
        isOpen={returnModalOpen}
        onClose={() => setReturnModalOpen(false)}
        onTrackQueue={() => {
          setCurrentView('patient');
          setPatientSubView('tracker');
        }}
      />

      {/* 6. Floating Demo Controller for Reviewers / Evaluators */}
      {currentView !== 'kiosk' && (
        <DemoController
          currentView={currentView}
          setCurrentView={(v) => {
            setCurrentView(v);
            if (v === 'patient') setPatientSubView('tracker');
          }}
        />
      )}

    </div>
  );
};

export function App() {
  return (
    <LanguageProvider>
      <QueueProvider>
        <MainAppContent />
      </QueueProvider>
    </LanguageProvider>
  );
}

export default App;
