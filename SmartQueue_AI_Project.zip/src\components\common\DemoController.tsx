import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  FastForward, 
  AlertOctagon, 
  Sliders, 
  ChevronUp, 
  ChevronDown, 
  RotateCcw,
  Sparkles,
  Users
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';

interface DemoControllerProps {
  currentView: string;
  setCurrentView: (view: any) => void;
}

export const DemoController: React.FC<DemoControllerProps> = ({
  currentView,
  setCurrentView
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isAutoSimulating, setIsAutoSimulating] = useState(false);
  const { 
    advanceQueueSimulation, 
    updatePatientPriority, 
    tokens, 
    resetToDemoData,
    departments
  } = useQueue();

  const cardioDept = departments.find(d => d.id === 'cardiology');
  const primaryToken = tokens.find(t => t.id === 'tok-c127');

  // Auto-simulation timer
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (isAutoSimulating) {
      interval = setInterval(() => {
        advanceQueueSimulation();
      }, 8000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isAutoSimulating, advanceQueueSimulation]);

  const handleSimulateEmergency = () => {
    if (primaryToken) {
      updatePatientPriority(primaryToken.id, 'emergency', true);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Collapsed Pill Button */}
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center space-x-2 px-3.5 py-2.5 bg-slate-900 text-white rounded-full shadow-2xl hover:bg-slate-800 transition border border-slate-700 font-medium text-xs group"
        >
          <Sparkles className="w-4 h-4 text-brand-400 animate-spin" />
          <span>Live Demo Simulator</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <ChevronUp className="w-4 h-4 text-slate-400 group-hover:text-white" />
        </button>
      ) : (
        /* Expanded Floating Control Panel */
        <div className="bg-slate-900/95 backdrop-blur-md text-white border border-slate-700/80 rounded-2xl shadow-2xl p-4 w-80 animate-in fade-in slide-in-from-bottom-3 duration-200">
          
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-brand-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Evaluation Simulator
              </span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-1 rounded-md transition"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          {/* Current State Summary */}
          <div className="my-3 p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs space-y-1.5">
            <div className="flex justify-between items-center text-slate-300">
              <span>Cardiology Serving:</span>
              <strong className="text-emerald-400 font-mono text-sm">{cardioDept?.currentServingToken || 'C-119'}</strong>
            </div>
            <div className="flex justify-between items-center text-slate-300">
              <span>Rithika M's Token (C-127):</span>
              <span className={`font-semibold ${primaryToken?.status === 'serving' ? 'text-red-400 font-bold animate-pulse' : 'text-brand-300'}`}>
                {primaryToken?.status === 'serving' 
                  ? 'NOW SERVING' 
                  : `${primaryToken?.patientsAhead ?? 0} ahead (~${primaryToken?.estimatedWaitMinutes ?? 0}m)`}
              </span>
            </div>
          </div>

          {/* Simulation Trigger Buttons */}
          <div className="space-y-2">
            <button
              onClick={() => advanceQueueSimulation()}
              className="w-full py-2 px-3 rounded-lg bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs flex items-center justify-center space-x-2 shadow-md transition"
            >
              <FastForward className="w-4 h-4" />
              <span>Advance Queue (Call Next)</span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setIsAutoSimulating(!isAutoSimulating)}
                className={`py-1.5 px-2.5 rounded-lg text-xs font-medium flex items-center justify-center space-x-1.5 border transition ${
                  isAutoSimulating 
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300' 
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {isAutoSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isAutoSimulating ? 'Stop Auto (8s)' : 'Auto Run (8s)'}</span>
              </button>

              <button
                onClick={handleSimulateEmergency}
                className="py-1.5 px-2.5 rounded-lg bg-red-950/60 border border-red-700/50 hover:bg-red-900/60 text-red-300 text-xs font-medium flex items-center justify-center space-x-1.5 transition"
              >
                <AlertOctagon className="w-3.5 h-3.5 text-red-400" />
                <span>Mark C-127 Urgent</span>
              </button>
            </div>
          </div>

          {/* Quick Screen Switchers */}
          <div className="mt-3 pt-3 border-t border-slate-800">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block mb-1.5">
              Jump to Screen:
            </span>
            <div className="grid grid-cols-2 gap-1.5 text-[11px]">
              <button
                onClick={() => setCurrentView('landing')}
                className={`py-1 px-2 rounded text-left transition ${currentView === 'landing' ? 'bg-brand-700 text-white font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              >
                1. Landing Page
              </button>
              <button
                onClick={() => setCurrentView('patient')}
                className={`py-1 px-2 rounded text-left transition ${currentView === 'patient' ? 'bg-brand-700 text-white font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              >
                2. Patient Portal
              </button>
              <button
                onClick={() => setCurrentView('admin')}
                className={`py-1 px-2 rounded text-left transition ${currentView === 'admin' ? 'bg-brand-700 text-white font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              >
                3. Admin Dashboard
              </button>
              <button
                onClick={() => setCurrentView('kiosk')}
                className={`py-1 px-2 rounded text-left transition ${currentView === 'kiosk' ? 'bg-brand-700 text-white font-bold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              >
                4. Waiting TV Kiosk
              </button>
            </div>
          </div>

          {/* Reset button */}
          <button
            onClick={() => resetToDemoData()}
            className="w-full mt-3 py-1 text-[11px] text-slate-400 hover:text-red-400 flex items-center justify-center space-x-1 transition"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Demo State</span>
          </button>

        </div>
      )}
    </div>
  );
};
