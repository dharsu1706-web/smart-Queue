import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Department, 
  Doctor, 
  DoctorStatus, 
  HistoricalVisit, 
  NotificationItem, 
  Patient, 
  PatientFlowStage, 
  PriorityCategory, 
  QueueToken, 
  TokenStatus, 
  VisitType 
} from '../types/queue';
import { 
  DEFAULT_HOSPITAL_NAME, 
  DEMO_PATIENT, 
  INITIAL_DEPARTMENTS, 
  INITIAL_DOCTORS, 
  INITIAL_FLOW_STAGES, 
  INITIAL_TOKENS, 
  INITIAL_VISIT_HISTORY 
} from '../data/mockData';
import { calculateAIPrediction } from '../services/aiPredictionService';

interface GenerateTokenParams {
  hospitalName?: string;
  departmentId: string;
  doctorId: string;
  visitType: VisitType;
  category?: PriorityCategory;
  symptoms?: string;
}

interface QueueContextType {
  hospitalName: string;
  setHospitalName: (name: string) => void;
  departments: Department[];
  doctors: Doctor[];
  tokens: QueueToken[];
  currentPatient: Patient;
  setCurrentPatient: (patient: Patient) => void;
  activeToken: QueueToken | undefined;
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  flowStages: PatientFlowStage[];
  historicalVisits: HistoricalVisit[];
  
  // Actions
  generateToken: (params: GenerateTokenParams) => QueueToken;
  callNextToken: (departmentId: string) => void;
  updatePatientPriority: (tokenId: string, category: PriorityCategory, isEmergency?: boolean) => void;
  movePatientInQueue: (tokenId: string, direction: 'up' | 'down') => void;
  updateDoctorStatus: (doctorId: string, status: DoctorStatus) => void;
  pauseResumeQueue: (departmentId: string, paused: boolean) => void;
  addDoctor: (doc: Omit<Doctor, 'id'>) => void;
  removeDoctor: (doctorId: string) => void;
  markEnRoute: (tokenId: string) => void;
  snoozeNotification: (tokenId: string, minutes: number) => void;
  cancelToken: (tokenId: string) => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
  advanceQueueSimulation: () => void;
  resetToDemoData: () => void;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

const STORAGE_KEY = 'smartqueue_ai_state_v1';

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load saved state or default
  const [hospitalName, setHospitalName] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { return JSON.parse(saved).hospitalName || DEFAULT_HOSPITAL_NAME; } catch { /* ignore */ }
    }
    return DEFAULT_HOSPITAL_NAME;
  });

  const [departments, setDepartments] = useState<Department[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { return JSON.parse(saved).departments || INITIAL_DEPARTMENTS; } catch { /* ignore */ }
    }
    return INITIAL_DEPARTMENTS;
  });

  const [doctors, setDoctors] = useState<Doctor[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { return JSON.parse(saved).doctors || INITIAL_DOCTORS; } catch { /* ignore */ }
    }
    return INITIAL_DOCTORS;
  });

  const [tokens, setTokens] = useState<QueueToken[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { return JSON.parse(saved).tokens || INITIAL_TOKENS; } catch { /* ignore */ }
    }
    return INITIAL_TOKENS;
  });

  const [currentPatient, setCurrentPatient] = useState<Patient>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { return JSON.parse(saved).currentPatient || DEMO_PATIENT; } catch { /* ignore */ }
    }
    return DEMO_PATIENT;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-init-1',
      type: 'token_generated',
      title: 'Digital Token Generated',
      message: 'Token C-127 successfully generated for Cardiology (Dr. Kumar). Track your queue in real time.',
      tokenNumber: 'C-127',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      urgency: 'normal'
    },
    {
      id: 'notif-init-2',
      type: 'waiting_time_changed',
      title: 'AI Wait-Time Adjusted',
      message: 'Estimated wait is currently 42 minutes. We will alert you 10 minutes before your turn.',
      tokenNumber: 'C-127',
      timestamp: new Date(Date.now() - 5 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      urgency: 'low'
    }
  ]);

  const [flowStages, setFlowStages] = useState<PatientFlowStage[]>(INITIAL_FLOW_STAGES);
  const [historicalVisits, setHistoricalVisits] = useState<HistoricalVisit[]>(INITIAL_VISIT_HISTORY);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        hospitalName,
        departments,
        doctors,
        tokens,
        currentPatient
      }));
    } catch (e) {
      console.warn('LocalStorage sync error:', e);
    }
  }, [hospitalName, departments, doctors, tokens, currentPatient]);

  // Primary active token for current patient
  const activeToken = tokens.find(
    t => t.patientId === currentPatient.id && (t.status === 'waiting' || t.status === 'approaching' || t.status === 'serving')
  );

  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const newItem: NotificationItem = {
      ...notif,
      id: 'notif-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false
    };
    setNotifications(prev => [newItem, ...prev]);
  };

  // Generate new token
  const generateToken = ({
    hospitalName: hosp = hospitalName,
    departmentId,
    doctorId,
    visitType,
    category = currentPatient.category || 'general',
    symptoms = ''
  }: GenerateTokenParams): QueueToken => {
    const dept = departments.find(d => d.id === departmentId) || departments[0];
    const doc = doctors.find(d => d.id === doctorId) || doctors[0];

    // Count existing waiting patients in this dept
    const existingDeptTokens = tokens.filter(
      t => t.departmentId === departmentId && (t.status === 'waiting' || t.status === 'approaching')
    );
    const patientsAhead = existingDeptTokens.length;

    // Generate token number
    const sequenceNum = 120 + tokens.length + 1;
    const tokenNumber = `${dept.code}-${sequenceNum}`;

    // Calculate AI prediction
    const aiResult = calculateAIPrediction(
      patientsAhead,
      doc.status,
      doc.avgConsultationMinutes,
      category,
      dept.status === 'busy' ? 'High' : 'Medium'
    );

    const newToken: QueueToken = {
      id: 'tok-' + Date.now(),
      tokenNumber,
      patientId: currentPatient.id,
      patientName: currentPatient.name,
      patientPhone: currentPatient.mobile,
      patientAge: currentPatient.age,
      patientCategory: category,
      hospitalName: hosp,
      departmentId: dept.id,
      departmentName: dept.name,
      doctorId: doc.id,
      doctorName: doc.name,
      doctorRoom: doc.room,
      visitType,
      symptoms,
      generatedAt: new Date().toISOString(),
      estimatedWaitMinutes: aiResult.predictedWaitMinutes,
      aiConfidencePercent: aiResult.confidencePercent,
      patientsAhead,
      currentServingToken: dept.currentServingToken,
      status: 'waiting',
      priorityScore: category === 'emergency' ? 100 : category === 'senior' ? 75 : 50
    };

    setTokens(prev => [...prev, newToken]);

    // Update department stats
    setDepartments(prev => prev.map(d => {
      if (d.id === departmentId) {
        return {
          ...d,
          totalWaiting: d.totalWaiting + 1,
          avgWaitMinutes: Math.round((d.avgWaitMinutes + aiResult.predictedWaitMinutes) / 2)
        };
      }
      return d;
    }));

    // Update registration flow stage
    setFlowStages(prev => prev.map(stage => {
      if (stage.id === 'registration') {
        return { ...stage, count: stage.count + 1 };
      }
      return stage;
    }));

    addNotification({
      type: 'token_generated',
      title: 'Digital Token Generated!',
      message: `Token ${tokenNumber} generated for ${dept.name} (${doc.name}). Est. Wait: ${aiResult.predictedWaitMinutes} mins.`,
      tokenNumber,
      urgency: 'normal'
    });

    return newToken;
  };

  // Call Next Token in Department
  const callNextToken = (departmentId: string) => {
    const deptTokens = tokens.filter(
      t => t.departmentId === departmentId && (t.status === 'waiting' || t.status === 'approaching')
    );

    if (deptTokens.length === 0) return;

    // Pick token with highest priority score, or earliest created
    const sorted = [...deptTokens].sort((a, b) => {
      if (b.priorityScore !== a.priorityScore) {
        return b.priorityScore - a.priorityScore;
      }
      return new Date(a.generatedAt).getTime() - new Date(b.generatedAt).getTime();
    });

    const nextToken = sorted[0];

    // Update tokens state
    setTokens(prev => {
      return prev.map(tok => {
        if (tok.id === nextToken.id) {
          return {
            ...tok,
            status: 'serving' as TokenStatus,
            patientsAhead: 0,
            estimatedWaitMinutes: 0
          };
        }
        if (tok.departmentId === departmentId && tok.status === 'serving') {
          return {
            ...tok,
            status: 'completed' as TokenStatus
          };
        }
        if (tok.departmentId === departmentId && (tok.status === 'waiting' || tok.status === 'approaching')) {
          const newAhead = Math.max(0, tok.patientsAhead - 1);
          const newWait = Math.max(0, tok.estimatedWaitMinutes - 12);
          const isApproaching = newWait <= 15 && newWait > 0;
          return {
            ...tok,
            patientsAhead: newAhead,
            estimatedWaitMinutes: newWait,
            status: isApproaching ? ('approaching' as TokenStatus) : tok.status,
            currentServingToken: nextToken.tokenNumber
          };
        }
        return tok;
      });
    });

    // Update department current serving
    setDepartments(prev => prev.map(d => {
      if (d.id === departmentId) {
        return {
          ...d,
          currentServingToken: nextToken.tokenNumber,
          totalWaiting: Math.max(0, d.totalWaiting - 1)
        };
      }
      return d;
    }));

    // Update doctor's current serving token
    setDoctors(prev => prev.map(doc => {
      if (doc.departmentId === departmentId) {
        return {
          ...doc,
          currentServingToken: nextToken.tokenNumber,
          status: 'busy'
        };
      }
      return doc;
    }));

    // Check if next token is for current patient
    if (nextToken.patientId === currentPatient.id) {
      addNotification({
        type: 'your_turn',
        title: '🚨 YOUR TURN NOW!',
        message: `Token ${nextToken.tokenNumber} is now being served in ${nextToken.doctorRoom}. Please proceed inside immediately.`,
        tokenNumber: nextToken.tokenNumber,
        urgency: 'critical',
        actionRequired: true
      });
    } else {
      // Check if current patient is next in line or approaching
      const patientCardioToken = tokens.find(t => t.id === 'tok-c127' || t.patientId === currentPatient.id);
      if (patientCardioToken && patientCardioToken.departmentId === departmentId) {
        const remainingWait = Math.max(0, patientCardioToken.estimatedWaitMinutes - 12);
        if (remainingWait <= 15) {
          addNotification({
            type: 'turn_approaching',
            title: '🔔 Your Turn Is Approaching!',
            message: `Your token ${patientCardioToken.tokenNumber} will be called soon. Estimated remaining time: ~${remainingWait} mins. You can start returning to the hospital now.`,
            tokenNumber: patientCardioToken.tokenNumber,
            urgency: 'high',
            actionRequired: true
          });
        }
      }
    }
  };

  // Staff assigns or changes priority (Administrative Queue Triage)
  const updatePatientPriority = (tokenId: string, category: PriorityCategory, isEmergency: boolean = false) => {
    const weightMap: Record<PriorityCategory, number> = {
      emergency: 100,
      senior: 80,
      pregnant: 75,
      pwd: 75,
      child: 65,
      general: 50
    };

    setTokens(prev => prev.map(t => {
      if (t.id === tokenId) {
        const newScore = isEmergency ? 100 : weightMap[category];
        const newWait = isEmergency ? 2 : category === 'senior' ? Math.max(5, t.estimatedWaitMinutes - 10) : t.estimatedWaitMinutes;
        return {
          ...t,
          patientCategory: isEmergency ? 'emergency' : category,
          priorityScore: newScore,
          isEmergencyOverride: isEmergency,
          estimatedWaitMinutes: newWait
        };
      }
      return t;
    }));

    const targetToken = tokens.find(t => t.id === tokenId);
    if (targetToken) {
      addNotification({
        type: 'emergency_priority_update',
        title: isEmergency ? '🚨 Emergency Priority Activated' : 'Priority Category Updated',
        message: `Token ${targetToken.tokenNumber} priority adjusted to ${isEmergency ? 'EMERGENCY' : category.toUpperCase()}.`,
        tokenNumber: targetToken.tokenNumber,
        urgency: isEmergency ? 'critical' : 'normal'
      });
    }
  };

  const movePatientInQueue = (tokenId: string, direction: 'up' | 'down') => {
    setTokens(prev => {
      const idx = prev.findIndex(t => t.id === tokenId);
      if (idx === -1) return prev;
      const target = prev[idx];
      const delta = direction === 'up' ? 10 : -10;
      const updated = [...prev];
      updated[idx] = {
        ...target,
        priorityScore: Math.max(10, Math.min(100, target.priorityScore + delta))
      };
      return updated;
    });
  };

  const updateDoctorStatus = (doctorId: string, status: DoctorStatus) => {
    setDoctors(prev => prev.map(d => d.id === doctorId ? { ...d, status } : d));
    const doc = doctors.find(d => d.id === doctorId);
    if (doc) {
      addNotification({
        type: 'doctor_delayed',
        title: 'Doctor Status Updated',
        message: `${doc.name} status updated to: ${status.replace('-', ' ').toUpperCase()}.`,
        urgency: status === 'on-break' ? 'high' : 'normal'
      });
    }
  };

  const pauseResumeQueue = (departmentId: string, paused: boolean) => {
    setDepartments(prev => prev.map(d => {
      if (d.id === departmentId) {
        return {
          ...d,
          status: paused ? 'busy' : 'normal'
        };
      }
      return d;
    }));
    const dept = departments.find(d => d.id === departmentId);
    addNotification({
      type: 'queue_updated',
      title: paused ? '⏸ Queue Paused' : '▶ Queue Resumed',
      message: `${dept?.name} queue has been ${paused ? 'temporarily paused' : 'resumed'}.`,
      urgency: paused ? 'high' : 'normal'
    });
  };

  const addDoctor = (docData: Omit<Doctor, 'id'>) => {
    const newDoc: Doctor = {
      ...docData,
      id: 'doc-' + Date.now()
    };
    setDoctors(prev => [...prev, newDoc]);
    setDepartments(prev => prev.map(dept => {
      if (dept.id === docData.departmentId) {
        return {
          ...dept,
          assignedDoctorIds: [...dept.assignedDoctorIds, newDoc.id]
        };
      }
      return dept;
    }));
  };

  const removeDoctor = (doctorId: string) => {
    setDoctors(prev => prev.filter(d => d.id !== doctorId));
  };

  const markEnRoute = (tokenId: string) => {
    setTokens(prev => prev.map(t => t.id === tokenId ? { ...t, enRouteConfirmed: true } : t));
    addNotification({
      type: 'turn_approaching',
      title: 'En Route Confirmed! 🚗',
      message: 'Hospital reception has been alerted that you are returning. Your queue position is secured.',
      tokenNumber: tokens.find(t => t.id === tokenId)?.tokenNumber,
      urgency: 'normal'
    });
  };

  const snoozeNotification = (tokenId: string, minutes: number) => {
    const snoozeTime = new Date(Date.now() + minutes * 60000).toISOString();
    setTokens(prev => prev.map(t => t.id === tokenId ? { ...t, snoozedUntil: snoozeTime } : t));
    addNotification({
      type: 'waiting_time_changed',
      title: `Alarm Snoozed for ${minutes} mins`,
      message: `We will re-notify you in ${minutes} minutes.`,
      urgency: 'low'
    });
  };

  const cancelToken = (tokenId: string) => {
    setTokens(prev => prev.map(t => t.id === tokenId ? { ...t, status: 'cancelled' as TokenStatus } : t));
    addNotification({
      type: 'queue_updated',
      title: 'Token Cancelled',
      message: 'Your token was cancelled. You may generate a new token whenever you are ready.',
      urgency: 'normal'
    });
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  // Helper for manual demo simulation (e.g. advance Cardiology queue by 1 token)
  const advanceQueueSimulation = () => {
    callNextToken('cardiology');
  };

  const resetToDemoData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setHospitalName(DEFAULT_HOSPITAL_NAME);
    setDepartments(INITIAL_DEPARTMENTS);
    setDoctors(INITIAL_DOCTORS);
    setTokens(INITIAL_TOKENS);
    setCurrentPatient(DEMO_PATIENT);
    setFlowStages(INITIAL_FLOW_STAGES);
    setHistoricalVisits(INITIAL_VISIT_HISTORY);
    setNotifications([
      {
        id: 'notif-reset-1',
        type: 'queue_updated',
        title: 'System Reset',
        message: 'Demo dataset restored to City Care Hospital with Token C-127.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: false,
        urgency: 'normal'
      }
    ]);
  };

  return (
    <QueueContext.Provider
      value={{
        hospitalName,
        setHospitalName,
        departments,
        doctors,
        tokens,
        currentPatient,
        setCurrentPatient,
        activeToken,
        notifications,
        unreadNotificationCount,
        flowStages,
        historicalVisits,
        generateToken,
        callNextToken,
        updatePatientPriority,
        movePatientInQueue,
        updateDoctorStatus,
        pauseResumeQueue,
        addDoctor,
        removeDoctor,
        markEnRoute,
        snoozeNotification,
        cancelToken,
        markNotificationRead,
        clearAllNotifications,
        advanceQueueSimulation,
        resetToDemoData
      }}
    >
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = (): QueueContextType => {
  const context = useContext(QueueContext);
  if (!context) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
};
