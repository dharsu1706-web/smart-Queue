export type PriorityCategory = 
  | 'emergency'
  | 'senior'
  | 'pregnant'
  | 'child'
  | 'pwd'
  | 'general';

export type VisitType = 'appointment' | 'walk-in';

export type TokenStatus = 
  | 'waiting'
  | 'approaching'
  | 'serving'
  | 'completed'
  | 'cancelled'
  | 'no-show';

export type DoctorStatus = 
  | 'available'
  | 'busy'
  | 'in-consultation'
  | 'on-break'
  | 'offline';

export type QueueUrgency = 'normal' | 'busy' | 'emergency';

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  departmentId: string;
  departmentName: string;
  room: string;
  avatar: string;
  status: DoctorStatus;
  currentServingToken?: string;
  avgConsultationMinutes: number;
  experienceYears: number;
}

export interface Department {
  id: string;
  name: string;
  code: string; // e.g. 'C' for Cardiology
  icon: string;
  description: string;
  totalWaiting: number;
  avgWaitMinutes: number;
  status: QueueUrgency;
  currentServingToken: string;
  assignedDoctorIds: string[];
}

export interface Patient {
  id: string;
  name: string;
  mobile: string;
  email: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  category: PriorityCategory;
}

export interface QueueToken {
  id: string;
  tokenNumber: string; // e.g., "C-127"
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientAge: number;
  patientCategory: PriorityCategory;
  hospitalName: string;
  departmentId: string;
  departmentName: string;
  doctorId: string;
  doctorName: string;
  doctorRoom: string;
  visitType: VisitType;
  symptoms?: string;
  generatedAt: string; // ISO string
  estimatedWaitMinutes: number;
  aiConfidencePercent: number;
  patientsAhead: number;
  currentServingToken: string;
  status: TokenStatus;
  isEmergencyOverride?: boolean;
  priorityScore: number; // calculated priority weight
  enRouteConfirmed?: boolean;
  snoozedUntil?: string;
}

export interface NotificationItem {
  id: string;
  type: 
    | 'token_generated'
    | 'queue_updated'
    | 'waiting_time_changed'
    | 'turn_approaching'
    | 'your_turn'
    | 'doctor_delayed'
    | 'emergency_priority_update';
  title: string;
  message: string;
  tokenNumber?: string;
  timestamp: string;
  read: boolean;
  actionRequired?: boolean;
  urgency: 'low' | 'normal' | 'high' | 'critical';
}

export interface PatientFlowStage {
  id: 'registration' | 'consultation' | 'lab' | 'pharmacy' | 'billing';
  label: string;
  count: number;
  avgDwellMinutes: number;
  status: 'normal' | 'congested' | 'optimal';
  icon: string;
}

export interface AIPredictionFactors {
  currentQueueCount: number;
  doctorAvailabilityStatus: string;
  doctorVelocityFactor: number;
  departmentWorkloadIndex: 'Low' | 'Medium' | 'High' | 'Critical';
  avgConsultationTimeMinutes: number;
  historicalWaitTrendOffset: number;
  emergencyPreemptionCount: number;
}

export interface AIPredictionResult {
  predictedWaitMinutes: number;
  confidencePercent: number;
  factors: AIPredictionFactors;
  explanation: string;
  generatedAt: string;
}

export interface HistoricalVisit {
  id: string;
  date: string;
  hospital: string;
  department: string;
  doctor: string;
  tokenNumber: string;
  waitingMinutes: number;
  status: 'Completed' | 'Cancelled' | 'Missed';
  notes: string;
}
