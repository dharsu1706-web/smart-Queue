import React, { useState } from 'react';
import { 
  Activity, 
  Bell, 
  Menu, 
  X, 
  User, 
  Building2, 
  Tv, 
  RotateCcw,
  Sparkles,
  ChevronDown,
  Globe
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { useLanguage } from '../../context/LanguageContext';

interface NavbarProps {
  currentView: 'landing' | 'patient' | 'admin' | 'kiosk' | 'auth-patient' | 'auth-admin';
  setCurrentView: (view: 'landing' | 'patient' | 'admin' | 'kiosk' | 'auth-patient' | 'auth-admin') => void;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  onOpenNotifications
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [switchDropdownOpen, setSwitchDropdownOpen] = useState(false);
  const { 
    hospitalName, 
    currentPatient, 
    unreadNotificationCount, 
    activeToken,
    resetToDemoData 
  } = useQueue();
  const { language, toggleLanguage, t } = useLanguage();

  const handleNavClick = (view: 'landing' | 'patient' | 'admin' | 'kiosk' | 'auth-patient' | 'auth-admin') => {
    setCurrentView(view);
    setMobileMenuOpen(false);
    setSwitchDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Hospital Name */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleNavClick('landing')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-brand-500/20">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  SmartQueue<span className="text-brand-600">AI</span>
                </span>
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                  <Sparkles className="w-2.5 h-2.5 mr-0.5 text-emerald-600" /> {t.live}
                </span>
              </div>
              <p className="text-[11px] text-slate-700 font-medium truncate max-w-[180px] sm:max-w-xs">
                {hospitalName}
              </p>
            </div>
          </div>

          {/* Center Navigation Links (Public Landing Links) */}
          <nav className="hidden lg:flex items-center space-x-6 text-sm font-medium text-slate-600">
            <button 
              onClick={() => handleNavClick('landing')}
              className={`hover:text-brand-600 transition-colors ${currentView === 'landing' ? 'text-brand-600 font-semibold' : ''}`}
            >
              {t.home}
            </button>
            <a href="#how-it-works" onClick={() => setCurrentView('landing')} className="hover:text-brand-600 transition-colors">
              {t.howItWorks}
            </a>
            <a href="#features" onClick={() => setCurrentView('landing')} className="hover:text-brand-600 transition-colors">
              {t.features}
            </a>
            <a href="#for-hospitals" onClick={() => setCurrentView('landing')} className="hover:text-brand-600 transition-colors">
              {t.forHospitals}
            </a>
            <a href="#about" onClick={() => setCurrentView('landing')} className="hover:text-brand-600 transition-colors">
              {t.about}
            </a>
          </nav>

          {/* Right Actions & Portal Quick Toggles */}
          <div className="hidden md:flex items-center space-x-3">
            
            {/* Language Switcher Button (English / தமிழ்) */}
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-800 transition shadow-xs"
              title={language === 'en' ? 'தமிழில் மாற்றவும்' : 'Switch to English'}
            >
              <Globe className="w-3.5 h-3.5 text-brand-600" />
              <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
            </button>

            {/* View Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setSwitchDropdownOpen(!switchDropdownOpen)}
                className="flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-700 transition"
              >
                <span>{t.switchPortal}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {switchDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                    {t.switchPortal}
                  </div>
                  <button
                    onClick={() => handleNavClick('landing')}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center space-x-2 text-slate-700"
                  >
                    <Activity className="w-4 h-4 text-brand-600" />
                    <span>{t.home}</span>
                  </button>
                  <button
                    onClick={() => handleNavClick('patient')}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center space-x-2 text-slate-700"
                  >
                    <User className="w-4 h-4 text-emerald-600" />
                    <div>
                      <div className="font-medium">{t.patientPortal}</div>
                      <div className="text-[10px] text-slate-600">Logged in as {currentPatient.name}</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleNavClick('admin')}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center space-x-2 text-slate-700"
                  >
                    <Building2 className="w-4 h-4 text-brand-600" />
                    <div>
                      <div className="font-medium">Hospital Admin Dashboard</div>
                      <div className="text-[10px] text-slate-600">OPD & Queue Control</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleNavClick('kiosk')}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 flex items-center space-x-2 text-slate-700"
                  >
                    <Tv className="w-4 h-4 text-purple-600" />
                    <div>
                      <div className="font-medium">{t.kioskDisplay}</div>
                      <div className="text-[10px] text-slate-600">Fullscreen TV Board</div>
                    </div>
                  </button>
                  <div className="border-t border-slate-100 my-1"></div>
                  <button
                    onClick={() => {
                      resetToDemoData();
                      setSwitchDropdownOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-red-50 text-red-600 flex items-center space-x-2"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{t.resetDemo}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-lg text-slate-600 hover:text-brand-600 hover:bg-slate-100 transition"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationCount > 0 && (
                <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ring-2 ring-white">
                  {unreadNotificationCount}
                </span>
              )}
            </button>

            {/* Direct Switch Buttons */}
            {currentView === 'landing' ? (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleNavClick('patient')}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-brand-50 text-brand-700 hover:bg-brand-100 transition border border-brand-200"
                >
                  {t.patientPortal}
                </button>
                <button
                  onClick={() => handleNavClick('admin')}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-brand-600 text-white hover:bg-brand-700 shadow-sm shadow-brand-600/30 transition"
                >
                  {t.hospitalLogin}
                </button>
              </div>
            ) : currentView === 'patient' ? (
              <div className="flex items-center space-x-2">
                {activeToken && (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Token: <strong className="ml-1 text-emerald-800 font-bold">{activeToken.tokenNumber}</strong>
                  </span>
                )}
                <button
                  onClick={() => handleNavClick('admin')}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                >
                  Switch to Admin
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleNavClick('patient')}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
              >
                Switch to Patient
              </button>
            )}
          </div>

          {/* Mobile Actions: Language toggle + Menu Button */}
          <div className="flex items-center space-x-2 md:hidden">
            <button
              onClick={toggleLanguage}
              className="p-1.5 px-2.5 rounded-lg border border-slate-300 text-xs font-bold text-slate-800 bg-slate-50 flex items-center space-x-1"
            >
              <Globe className="w-3.5 h-3.5 text-brand-600" />
              <span>{language === 'en' ? 'தமிழ்' : 'EN'}</span>
            </button>
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-lg text-slate-600 hover:text-brand-600 hover:bg-slate-100"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationCount > 0 && (
                <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                  {unreadNotificationCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2 pb-2">
            <button
              onClick={() => handleNavClick('patient')}
              className={`p-2.5 rounded-lg text-xs font-semibold text-center border ${
                currentView === 'patient' ? 'bg-brand-50 border-brand-300 text-brand-700' : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
            >
              {t.patientPortal}
            </button>
            <button
              onClick={() => handleNavClick('admin')}
              className={`p-2.5 rounded-lg text-xs font-semibold text-center border ${
                currentView === 'admin' ? 'bg-brand-50 border-brand-300 text-brand-700' : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
            >
              Hospital Admin
            </button>
            <button
              onClick={() => handleNavClick('landing')}
              className="p-2.5 rounded-lg text-xs font-semibold text-center border bg-slate-50 border-slate-200 text-slate-700"
            >
              {t.home}
            </button>
            <button
              onClick={() => handleNavClick('kiosk')}
              className="p-2.5 rounded-lg text-xs font-semibold text-center border bg-purple-50 border-purple-200 text-purple-700"
            >
              {t.kioskDisplay}
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-1">
            <a 
              href="#how-it-works" 
              onClick={() => { setCurrentView('landing'); setMobileMenuOpen(false); }} 
              className="block px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
            >
              {t.howItWorks}
            </a>
            <a 
              href="#features" 
              onClick={() => { setCurrentView('landing'); setMobileMenuOpen(false); }} 
              className="block px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
            >
              {t.features}
            </a>
            <a 
              href="#for-hospitals" 
              onClick={() => { setCurrentView('landing'); setMobileMenuOpen(false); }} 
              className="block px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
            >
              {t.forHospitals}
            </a>
            <button
              onClick={() => { resetToDemoData(); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-red-600 hover:bg-red-50"
            >
              {t.resetDemo}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
