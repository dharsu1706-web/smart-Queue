import React, { useState } from 'react';
import { 
  BrainCircuit, 
  Sparkles, 
  Clock, 
  Users, 
  Activity, 
  TrendingDown, 
  Gauge, 
  Layers, 
  Cpu, 
  CheckCircle2, 
  Code2, 
  Info,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { calculateAIPrediction } from '../../services/aiPredictionService';

export const AIPredictionCard: React.FC = () => {
  const { activeToken, doctors, departments } = useQueue();
  const [showMLSchema, setShowMLSchema] = useState(false);

  const doc = doctors.find(d => d.id === activeToken?.doctorId);
  const dept = departments.find(d => d.id === activeToken?.departmentId);

  const patientsAhead = activeToken?.patientsAhead ?? 8;
  const doctorStatus = doc?.status ?? 'available';
  const avgConsultTime = doc?.avgConsultationMinutes ?? 12;
  const departmentWorkload = dept?.status === 'busy' ? 'High' : 'Medium';

  const aiResult = calculateAIPrediction(
    patientsAhead,
    doctorStatus,
    avgConsultTime,
    activeToken?.patientCategory || 'general',
    departmentWorkload as any
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 rounded-2xl text-white p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-purple-400/20 text-purple-300 text-xs font-semibold">
              <BrainCircuit className="w-3.5 h-3.5 text-purple-300" />
              <span>SmartQueue M/M/c Predictive Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              AI Waiting-Time Prediction
            </h1>
            <p className="text-xs sm:text-sm text-purple-200 leading-relaxed">
              Dynamically synthesized using real-time patient flow, clinician consultation pace, department load index, and historical queueing patterns.
            </p>
          </div>

          {/* Large Time & Confidence Badge */}
          <div className="p-5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center shrink-0 min-w-[200px]">
            <div className="text-[11px] uppercase tracking-wider text-purple-200 font-bold">
              AI Estimated Wait
            </div>
            <div className="text-4xl sm:text-5xl font-black text-white mt-1">
              {activeToken?.estimatedWaitMinutes ?? 42} <span className="text-lg font-medium text-purple-200">min</span>
            </div>
            <div className="mt-2 inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 text-xs font-bold">
              <Sparkles className="w-3 h-3 text-emerald-300" />
              <span>{activeToken?.aiConfidencePercent ?? 87}% Confidence</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Key Influencing Factors Breakdown (From Project PPT) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 card-shadow space-y-6">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">
            Factors Affecting This AI Prediction
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            These 4 core variables from the hospital PPT directly weight the dynamic wait algorithm:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Factor 1: Current Patient Flow */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-brand-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div className="text-xs text-slate-500">Current Queue Flow</div>
            <div className="text-lg font-bold text-slate-900">
              {patientsAhead} patients ahead
            </div>
            <p className="text-[11px] text-slate-400">
              Active tokens pending in {dept?.name || 'Cardiology'}
            </p>
          </div>

          {/* Factor 2: Doctor Availability */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
            <div className="text-xs text-slate-500">Doctor Availability</div>
            <div className="text-lg font-bold text-slate-900 capitalize">
              {doctorStatus.replace('-', ' ')}
            </div>
            <p className="text-[11px] text-slate-400">
              Dr. {doc?.name || 'Kumar Ramanathan'} (On duty)
            </p>
          </div>

          {/* Factor 3: Department Workload */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div className="text-xs text-slate-500">Department Workload</div>
            <div className="text-lg font-bold text-slate-900">
              {departmentWorkload}
            </div>
            <p className="text-[11px] text-slate-400">
              Hospital OPD utilization index
            </p>
          </div>

          {/* Factor 4: Historical Queue Data / Avg Consultation */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <div className="text-xs text-slate-500">Avg Consultation Time</div>
            <div className="text-lg font-bold text-slate-900">
              {avgConsultTime} min / patient
            </div>
            <p className="text-[11px] text-slate-400">
              Empirical historical mean for specialty
            </p>
          </div>

        </div>

        {/* AI Confidence Meter Gauge */}
        <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <Gauge className="w-4 h-4 text-purple-600" />
              <h4 className="text-xs font-bold text-purple-900">Confidence Calibration Analysis</h4>
            </div>
            <p className="text-xs text-purple-800">
              High confidence score (87%) is driven by consistent consultation pace in Cardiology Cabin 104 with no sudden emergency preemption spikes.
            </p>
          </div>
          <div className="w-full sm:w-48 bg-purple-200 h-3 rounded-full overflow-hidden shrink-0">
            <div 
              className="bg-purple-600 h-full rounded-full transition-all duration-500" 
              style={{ width: `${activeToken?.aiConfidencePercent ?? 87}%` }}
            />
          </div>
        </div>

      </div>

      {/* 3. ML Architecture & Python / FastAPI Backend Connector */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 card-shadow space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Code2 className="w-5 h-5 text-slate-700" />
            <h3 className="text-sm font-bold text-slate-900">
              Machine Learning Backend Integration Architecture
            </h3>
          </div>
          <button
            onClick={() => setShowMLSchema(!showMLSchema)}
            className="text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center space-x-1"
          >
            <span>{showMLSchema ? 'Hide API Contract' : 'View Python/FastAPI ML Contract'}</span>
            {showMLSchema ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          The prototype runs a calibrated queueing theory regression model on the client side (`calculateAIPrediction`). It is fully structured to swap in an external Python machine learning model (e.g., XGBoost / Random Forest trained on hospital electronic health logs).
        </p>

        {showMLSchema && (
          <div className="p-4 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono overflow-x-auto space-y-2 border border-slate-800">
            <div className="text-brand-400 font-bold"># Python / FastAPI Target Endpoint: POST /api/v1/predict-wait-time</div>
            <pre className="text-slate-300">
{`{
  "hospital_id": "CITYCARE-01",
  "department": "${activeToken?.departmentId || 'cardiology'}",
  "patients_ahead": ${patientsAhead},
  "doctor_availability": "${doctorStatus}",
  "avg_consultation_minutes": ${avgConsultTime},
  "department_workload_index": "${departmentWorkload}",
  "patient_priority": "${activeToken?.patientCategory || 'general'}",
  "time_of_day": "${new Date().toISOString()}"
}

# Expected Prediction Response:
{
  "predicted_wait_minutes": ${activeToken?.estimatedWaitMinutes || 42},
  "confidence_percent": 87.4,
  "confidence_interval_95": [38.5, 45.2],
  "model_version": "SmartQueue-XGBoost-v2.4"
}`}
            </pre>
          </div>
        )}
      </div>

    </div>
  );
};
