import React from 'react';
import { 
  ArrowRight, 
  UserCheck, 
  Stethoscope, 
  FlaskConical, 
  Pill, 
  Receipt, 
  AlertCircle, 
  CheckCircle2, 
  TrendingUp,
  Activity,
  Layers
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { PatientFlowStage } from '../../types/queue';

export const PatientFlowMonitor: React.FC = () => {
  const { flowStages } = useQueue();

  const getStageIcon = (id: PatientFlowStage['id']) => {
    switch (id) {
      case 'registration':
        return <UserCheck className="w-6 h-6 text-brand-600" />;
      case 'consultation':
        return <Stethoscope className="w-6 h-6 text-purple-600" />;
      case 'lab':
        return <FlaskConical className="w-6 h-6 text-emerald-600" />;
      case 'pharmacy':
        return <Pill className="w-6 h-6 text-amber-600" />;
      case 'billing':
        return <Receipt className="w-6 h-6 text-cyan-600" />;
    }
  };

  const totalPatientsInJourney = flowStages.reduce((acc, s) => acc + s.count, 0);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Layers className="w-5 h-5 text-brand-600" />
            <h2 className="text-xl font-extrabold text-slate-900">
              Live Patient Flow Journey Monitoring
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Real-time tracking across the 5 core stages of the hospital journey highlighted in the project PPT. Identifies OPD bottlenecks before congestion cascades.
          </p>
        </div>

        <div className="p-3 rounded-xl bg-brand-50 border border-brand-200 text-center shrink-0">
          <div className="text-[10px] uppercase font-bold text-brand-700">Total in Transit</div>
          <div className="text-2xl font-black text-brand-900">{totalPatientsInJourney} Patients</div>
        </div>
      </div>

      {/* 5-Stage Hospital Journey Visualization (Pipeline Flow) */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 card-shadow space-y-8">
        
        {/* Visual Pipeline with Connecting Arrows */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
          {flowStages.map((stage, idx) => (
            <div 
              key={stage.id} 
              className={`p-5 rounded-2xl border-2 transition relative flex flex-col justify-between ${
                stage.status === 'congested' 
                  ? 'border-amber-400 bg-amber-50/50 shadow-md' 
                  : 'border-slate-200 bg-slate-50/80 hover:border-slate-300'
              }`}
            >
              {/* Step Number Badge */}
              <div className="flex items-center justify-between mb-3">
                <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center">
                  {idx + 1}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                  stage.status === 'congested' 
                    ? 'bg-amber-200 text-amber-900 animate-pulse' 
                    : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {stage.status === 'congested' ? 'Bottleneck' : 'Optimal'}
                </span>
              </div>

              {/* Icon & Stage Name */}
              <div className="space-y-1 mb-4">
                <div className="p-2 rounded-xl bg-white shadow-sm inline-block mb-1">
                  {getStageIcon(stage.id)}
                </div>
                <h4 className="text-sm font-bold text-slate-900">{stage.label}</h4>
                <div className="text-[11px] text-slate-500">Avg dwell: ~{stage.avgDwellMinutes} min</div>
              </div>

              {/* Patient Count */}
              <div className="pt-3 border-t border-slate-200/80 flex items-baseline justify-between">
                <span className="text-xs text-slate-500 font-medium">Active:</span>
                <span className={`text-2xl font-black ${
                  stage.status === 'congested' ? 'text-amber-700' : 'text-slate-900'
                }`}>
                  {stage.count}
                </span>
              </div>

            </div>
          ))}
        </div>

        {/* Journey Flow Infographic Summary */}
        <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">OPD Transit Bottleneck Intelligence</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Stage 2 (Doctor Consultation: 18 patients) is operating near peak capacity. SmartQueue remote throttle is actively pacing patient return alerts.
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-mono font-bold whitespace-nowrap">
            Lobby Congestion: -42%
          </span>
        </div>

      </div>

    </div>
  );
};
