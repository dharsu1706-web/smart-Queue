import React, { useState } from 'react';
import { 
  Bell, 
  Car, 
  Clock, 
  MapPin, 
  AlertCircle, 
  CheckCircle2, 
  Navigation, 
  Volume2, 
  X 
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { useLanguage } from '../../context/LanguageContext';

interface SmartReturnNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTrackQueue: () => void;
}

export const SmartReturnNotificationModal: React.FC<SmartReturnNotificationModalProps> = ({
  isOpen,
  onClose,
  onTrackQueue
}) => {
  const { activeToken, markEnRoute, snoozeNotification } = useQueue();
  const { t, language } = useLanguage();
  const [snoozeOpen, setSnoozeOpen] = useState(false);

  if (!isOpen || !activeToken) return null;

  const handleReturnNow = () => {
    markEnRoute(activeToken.id);
    onClose();
  };

  const handleSnooze = (minutes: number) => {
    snoozeNotification(activeToken.id, minutes);
    setSnoozeOpen(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 text-center space-y-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Bell Icon with Radar Pulse */}
        <div className="relative w-20 h-20 mx-auto">
          <div className="absolute inset-0 bg-amber-400/30 rounded-full animate-ping"></div>
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-lg shadow-amber-500/30">
            <Bell className="w-10 h-10 animate-bounce" />
          </div>
        </div>

        {/* Headline */}
        <div>
          <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-amber-100 text-amber-800">
            {language === 'ta' ? 'ஸ்மார்ட் வரிசை அருகாமை எச்சரிக்கை' : 'Smart Queue Proximity Alert'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
            {t.turnApproachingTitle}
          </h2>
          <p className="text-sm font-semibold text-slate-700 mt-1">
            {language === 'ta' 
              ? `உங்கள் டோக்கன் ${activeToken.tokenNumber} விரைவில் அழைக்கப்படும்.` 
              : `Your token ${activeToken.tokenNumber} will be called soon.`}
          </p>
        </div>

        {/* Highlight Card: 10 minutes remaining */}
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200/90 text-amber-900 space-y-1">
          <div className="text-xs uppercase tracking-wider font-bold text-amber-700">
            {t.estRemainingTime}
          </div>
          <div className="text-4xl font-black text-amber-900">
            {activeToken.estimatedWaitMinutes > 0 ? activeToken.estimatedWaitMinutes : 10} {t.minutes}
          </div>
          <p className="text-xs font-medium text-amber-800 pt-1">
            {t.returnNowMsg}
          </p>
        </div>

        {/* Cabin Destination Details */}
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-left">
            <MapPin className="w-4 h-4 text-brand-600 shrink-0" />
            <div>
              <div className="font-bold text-slate-900">{activeToken.doctorName}</div>
              <div className="text-[11px] text-slate-500">{activeToken.doctorRoom}</div>
            </div>
          </div>
          <span className="font-mono font-bold text-brand-700 px-2 py-1 rounded bg-brand-50">
            Cabin OPD
          </span>
        </div>

        {/* Action Buttons: Return Now, Snooze, View Queue */}
        <div className="space-y-2.5 pt-1">
          <button
            onClick={handleReturnNow}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition active:scale-95 flex items-center justify-center space-x-2"
          >
            <Car className="w-5 h-5" />
            <span>{t.returnNowBtn}</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            {!snoozeOpen ? (
              <button
                onClick={() => setSnoozeOpen(true)}
                className="py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs transition"
              >
                {t.snoozeBtn}
              </button>
            ) : (
              <div className="col-span-2 flex items-center justify-center space-x-2 bg-slate-100 p-1.5 rounded-xl">
                <span className="text-xs text-slate-600 font-medium">Snooze:</span>
                <button
                  onClick={() => handleSnooze(5)}
                  className="px-2.5 py-1 rounded-lg bg-white text-xs font-bold text-slate-800 shadow-sm hover:bg-brand-50"
                >
                  5m
                </button>
                <button
                  onClick={() => handleSnooze(10)}
                  className="px-2.5 py-1 rounded-lg bg-white text-xs font-bold text-slate-800 shadow-sm hover:bg-brand-50"
                >
                  10m
                </button>
                <button
                  onClick={() => setSnoozeOpen(false)}
                  className="px-2 py-1 text-xs text-slate-500 hover:text-slate-700"
                >
                  ✕
                </button>
              </div>
            )}

            <button
              onClick={() => {
                onTrackQueue();
                onClose();
              }}
              className="py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition"
            >
              {t.viewQueueBtn}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
