import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  FileText, 
  Download, 
  Search, 
  CheckCircle2, 
  Building2, 
  User, 
  Filter,
  ArrowRight
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';

export const MyVisits: React.FC = () => {
  const { historicalVisits, currentPatient, hospitalName } = useQueue();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVisit, setSelectedVisit] = useState<any | null>(null);

  const filtered = historicalVisits.filter(v => 
    v.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.doctor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.tokenNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
        <div>
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-brand-600" />
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              My Visits & Consultation History
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Past consultations, token logs, waiting times, and digital prescriptions for {currentPatient.name}.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition flex items-center space-x-2 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Print / Export History</span>
        </button>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex items-center space-x-3 bg-white p-3 rounded-xl border border-slate-200">
        <Search className="w-4 h-4 text-slate-400 ml-2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by Department (e.g. Cardiology), Doctor, or Token Number..."
          className="w-full text-xs sm:text-sm focus:outline-none"
        />
      </div>

      {/* Historical Visits Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden card-shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-600 text-xs font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4 sm:px-6">Date</th>
                <th className="py-3.5 px-4 sm:px-6">Department</th>
                <th className="py-3.5 px-4 sm:px-6">Doctor</th>
                <th className="py-3.5 px-4 sm:px-6">Token</th>
                <th className="py-3.5 px-4 sm:px-6">Waiting Time</th>
                <th className="py-3.5 px-4 sm:px-6">Status</th>
                <th className="py-3.5 px-4 sm:px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filtered.map((visit) => (
                <tr key={visit.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-4 px-4 sm:px-6 text-slate-900 font-semibold whitespace-nowrap">
                    {visit.date}
                  </td>
                  <td className="py-4 px-4 sm:px-6 text-slate-800">
                    {visit.department}
                  </td>
                  <td className="py-4 px-4 sm:px-6 text-slate-700">
                    {visit.doctor}
                  </td>
                  <td className="py-4 px-4 sm:px-6 font-mono font-bold text-brand-600">
                    {visit.tokenNumber}
                  </td>
                  <td className="py-4 px-4 sm:px-6 text-slate-600">
                    {visit.waitingMinutes} min
                  </td>
                  <td className="py-4 px-4 sm:px-6">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                      ✓ {visit.status}
                    </span>
                  </td>
                  <td className="py-4 px-4 sm:px-6 text-right">
                    <button
                      onClick={() => setSelectedVisit(visit)}
                      className="text-xs font-semibold text-brand-600 hover:text-brand-800"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Visit Details Drawer / Modal */}
      {selectedVisit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-brand-600">
                  Consultation Summary
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                  Token {selectedVisit.tokenNumber} • {selectedVisit.department}
                </h3>
              </div>
              <button
                onClick={() => setSelectedVisit(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Date:</span>
                <strong className="text-slate-900">{selectedVisit.date}</strong>
              </div>
              <div className="flex justify-between">
                <span>Attending Doctor:</span>
                <strong className="text-slate-900">{selectedVisit.doctor}</strong>
              </div>
              <div className="flex justify-between">
                <span>Hospital:</span>
                <strong className="text-slate-900">{selectedVisit.hospital}</strong>
              </div>
              <div className="flex justify-between">
                <span>Total Waiting Time:</span>
                <strong className="text-slate-900">{selectedVisit.waitingMinutes} minutes</strong>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-700 mb-1">Doctor's Clinical Notes</h4>
              <p className="text-xs text-slate-600 bg-brand-50/50 p-3 rounded-xl border border-brand-100 leading-relaxed">
                {selectedVisit.notes}
              </p>
            </div>

            <button
              onClick={() => setSelectedVisit(null)}
              className="w-full py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
