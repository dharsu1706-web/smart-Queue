import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Clock, 
  User, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  RefreshCw, 
  Navigation, 
  Building2, 
  PhoneCall, 
  Volume2,
  Car,
  Bell,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { useLanguage } from '../../context/LanguageContext';

interface LiveQueueTrackerProps {
  onViewAIPrediction: () => void;
  onViewReturnModal: () => void;
  onBookAnotherToken: () => void;
}

export const LiveQueueTracker: React.FC<LiveQueueTrackerProps> = ({
  onViewAIPrediction,
  onViewReturnModal,
  onBookAnotherToken
}) => {
  const { 
    activeToken, 
    departments, 
    doctors, 
    markEnRoute, 
    hospitalName, 
    callNextToken 
  } = useQueue();
  const { t, language } = useLanguage();

  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());
  const [pulse, setPulse] = useState(false);

  // Auto-refresh simulation clock
  useEffect(() => {
    const timer = setInterval(() => {
      setLastUpdated(new Date().toLocaleTimeString());
      setPulse(prev => !prev);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  if (!activeToken) {
    return (
      <div className="max-w-2xl mx-auto py-16 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">
          {language === 'ta' ? 'செயலில் உள்ள டோக்கன் இல்லை' : 'No Active Token Being Tracked'}
        </h2>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          {language === 'ta'
            ? 'தற்போது உங்களிடம் கண்காணிக்க வேண்டிய டோக்கன் எதுவும் இல்லை. புதிய டோக்கனைப் பெறவும்.'
            : 'You do not have an active queue token in progress. Please generate a digital token to start real-time tracking.'}
        </p>
        <button
          onClick={onBookAnotherToken}
          className="px-6 py-2.5 rounded-xl bg-brand-600 text-white font-bold text-xs shadow-md"
        >
          {t.getNewToken}
        </button>
      </div>
    );
  }

  const dept = departments.find(d => d.id === activeToken.departmentId);
  const doc = doctors.find(d => d.id === activeToken.doctorId);

  const isServingNow = activeToken.status === 'serving';
  const isTurnApproaching = activeToken.estimatedWaitMinutes <= 15 && activeToken.estimatedWaitMinutes > 0;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      
      {/* 1. Header Ticker & Refresh Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 card-shadow flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900">
                {t.queueStatusTitle}
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1 animate-ping"></span> {t.live}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {hospitalName} • {activeToken.departmentName}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-500 self-end sm:self-auto">
          <RefreshCw className={`w-3.5 h-3.5 ${pulse ? 'rotate-180 transition-transform duration-500 text-brand-600' : 'text-slate-400'}`} />
          <span>{t.lastUpdated}: <strong className="text-slate-700">{lastUpdated}</strong></span>
        </div>
      </div>

      {/* 2. Approaching Turn Alert Banner */}
      {isTurnApproaching && (
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-in fade-in duration-300">
          <div className="flex items-start space-x-3">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm mt-0.5">
              <Bell className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="text-xs uppercase font-extrabold tracking-wider text-amber-100">
                Smart “Return Now” Notification
              </div>
              <h3 className="text-lg font-black text-white mt-0.5">
                {t.turnApproachingTitle} (~{activeToken.estimatedWaitMinutes} {t.minutes})
              </h3>
              <p className="text-xs text-amber-100 mt-1">
                {language === 'ta'
                  ? `உங்கள் டோக்கன் ${activeToken.tokenNumber} விரைவில் அழைக்கப்படும். நீங்கள் இப்போது மருத்துவமனைக்குத் திரும்பலாம்.`
                  : `Your token ${activeToken.tokenNumber} will be called shortly. You can start returning to the hospital now.`}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 self-start sm:self-auto">
            {!activeToken.enRouteConfirmed ? (
              <button
                onClick={() => markEnRoute(activeToken.id)}
                className="px-4 py-2.5 rounded-xl bg-white text-slate-900 font-bold text-xs shadow-md hover:bg-slate-50 transition active:scale-95 flex items-center space-x-1.5"
              >
                <Car className="w-4 h-4 text-brand-600" />
                <span>{t.returnNowBtn}</span>
              </button>
            ) : (
              <span className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold">
                {t.enRouteConfirmedMsg}
              </span>
            )}
            <button
              onClick={onViewReturnModal}
              className="px-3 py-2.5 rounded-xl bg-black/20 hover:bg-black/30 text-white text-xs font-semibold"
            >
              Details
            </button>
          </div>
        </div>
      )}

      {/* 3. Serving Now Emergency Banner */}
      {isServingNow && (
        <div className="p-5 rounded-2xl bg-emerald-600 text-white shadow-xl flex items-center justify-between emergency-pulse">
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-8 h-8 text-emerald-200 animate-pulse" />
            <div>
              <h3 className="text-xl font-black">
                {language === 'ta' ? 'உங்கள் டோக்கன் இப்போது அழைக்கப்படுகிறது!' : 'YOUR TOKEN IS BEING CALLED RIGHT NOW!'}
              </h3>
              <p className="text-xs text-emerald-100">
                {language === 'ta'
                  ? `உடனடியாக ${activeToken.doctorRoom} அறைக்குச் செல்லவும். மருத்துவர் ${activeToken.doctorName} காத்திருக்கிறார்.`
                  : `Please proceed directly inside ${activeToken.doctorRoom}. Dr. ${doc?.name || activeToken.doctorName} is waiting.`}
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-lg bg-white text-emerald-800 text-xs font-extrabold uppercase tracking-wider">
            {language === 'ta' ? 'அறைக்குச் செல்க' : 'Proceed to Cabin'}
          </span>
        </div>
      )}

      {/* 4. Primary Metrics Spotlight Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 card-shadow space-y-8">
        
        {/* Top Split: Your Token vs Current Serving */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center border-b border-slate-100 pb-8">
          
          {/* Your Token Block */}
          <div className="p-6 rounded-2xl bg-slate-900 text-white relative overflow-hidden space-y-3">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-400">
                {t.yourTokenNumber}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                {t[activeToken.patientCategory]?.toUpperCase() || activeToken.patientCategory.toUpperCase()}
              </span>
            </div>

            <div className="text-5xl font-black text-white font-mono tracking-tight">
              {activeToken.tokenNumber}
            </div>

            <div className="pt-1 text-xs text-slate-400 flex items-center justify-between">
              <span>Patient: <strong className="text-slate-200">{activeToken.patientName}</strong></span>
              <span>{activeToken.visitType}</span>
            </div>
          </div>

          {/* Current Serving Block */}
          <div className="p-6 rounded-2xl bg-brand-50/60 border border-brand-200 text-slate-900 space-y-3">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-700">
                {t.currentServing}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1 animate-pulse"></span>
                In Cabin
              </span>
            </div>

            <div className="text-5xl font-black text-brand-700 font-mono tracking-tight">
              {activeToken.currentServingToken}
            </div>

            <div className="pt-1 text-xs text-slate-600 flex items-center justify-between">
              <span>Doctor: <strong className="text-slate-900">{activeToken.doctorName}</strong></span>
              <span className="text-brand-600 font-medium">{activeToken.doctorRoom.split('-')[0]}</span>
            </div>
          </div>

        </div>

        {/* Patients Ahead & AI Wait Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-xs text-slate-500">{t.patientsAhead}</div>
            <div className="text-3xl font-extrabold text-amber-600 mt-1">
              {activeToken.patientsAhead}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">in queue line</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-xs text-slate-500">{t.aiEstWait}</div>
            <div className="text-3xl font-extrabold text-brand-600 mt-1">
              {activeToken.estimatedWaitMinutes} <span className="text-sm font-normal text-slate-500">{t.minutes}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">AI predicted</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-xs text-slate-500">{t.doctorStatus}</div>
            <div className="text-sm font-bold text-slate-900 mt-2 flex items-center justify-center">
              <span className={`w-2 h-2 rounded-full mr-1.5 ${doc?.status === 'available' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
              <span className="capitalize">{doc?.status?.replace('-', ' ') || 'Available'}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">~12 min / patient</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-xs text-slate-500">{t.queueStatus}</div>
            <div className="text-sm font-bold text-slate-900 mt-2 flex items-center justify-center">
              <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-50 text-emerald-700 capitalize">
                {dept?.status || 'Normal'}
              </span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">{dept?.totalWaiting || 8} waiting</div>
          </div>

        </div>

        {/* 5. Visual Progress Pipeline (Completed -> Current -> Your Token -> Remaining) */}
        <div className="space-y-3 pt-2">
          <div className="flex justify-between items-center text-xs font-bold text-slate-700">
            <span>{language === 'ta' ? 'வரிசை முன்னேற்றப் பாதை' : 'Visual Queue Pipeline'}</span>
            <span className="text-brand-600 font-semibold text-[11px]">
              {t.pipelineCompleted} → {t.pipelineServing} → {t.pipelineYourToken} → {t.pipelineRemaining}
            </span>
          </div>

          {/* Stepper Pipeline */}
          <div className="grid grid-cols-4 gap-2 sm:gap-3 text-center">
            
            {/* Stage 1: Completed */}
            <div className="p-3 rounded-xl bg-slate-100 border border-slate-200">
              <div className="w-7 h-7 rounded-full bg-slate-300 text-slate-700 font-bold text-xs flex items-center justify-center mx-auto mb-1">
                ✓
              </div>
              <div className="text-xs font-bold text-slate-800">{t.pipelineCompleted}</div>
              <div className="text-[10px] text-slate-500">{language === 'ta' ? 'முந்தைய டோக்கன்கள்' : 'Previous tokens'}</div>
            </div>

            {/* Stage 2: Current Serving */}
            <div className="p-3 rounded-xl bg-emerald-50 border-2 border-emerald-400">
              <div className="w-7 h-7 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center mx-auto mb-1 animate-pulse">
                •
              </div>
              <div className="text-xs font-bold text-emerald-900 font-mono">{activeToken.currentServingToken}</div>
              <div className="text-[10px] text-emerald-700 font-semibold">{t.pipelineServing}</div>
            </div>

            {/* Stage 3: Your Token */}
            <div className={`p-3 rounded-xl border-2 ${
              isServingNow 
                ? 'bg-emerald-100 border-emerald-500' 
                : 'bg-brand-50 border-brand-500 shadow-md'
            }`}>
              <div className="w-7 h-7 rounded-full bg-brand-600 text-white font-bold text-xs flex items-center justify-center mx-auto mb-1">
                ★
              </div>
              <div className="text-xs font-black text-brand-900 font-mono">{activeToken.tokenNumber}</div>
              <div className="text-[10px] text-brand-700 font-bold">{t.pipelineYourToken} ({activeToken.patientsAhead} {language === 'ta' ? 'முன்னால்' : 'ahead'})</div>
            </div>

            {/* Stage 4: Remaining */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-500 font-bold text-xs flex items-center justify-center mx-auto mb-1">
                ...
              </div>
              <div className="text-xs font-bold text-slate-700">{t.pipelineRemaining}</div>
              <div className="text-[10px] text-slate-400">{language === 'ta' ? 'அடுத்தவர்கள்' : 'Subsequent queue'}</div>
            </div>

          </div>
        </div>

        {/* Footer CTAs */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={onViewAIPrediction}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs border border-purple-200 transition flex items-center justify-center space-x-1.5"
          >
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span>{t.explainAi}</span>
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </button>

          <button
            onClick={() => callNextToken(activeToken.departmentId)}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition"
          >
            {t.advanceSimulate}
          </button>
        </div>

      </div>

    </div>
  );
};
