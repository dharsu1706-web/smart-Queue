import React, { useState } from 'react';
import { 
  User, 
  Lock, 
  Mail, 
  Phone, 
  Calendar, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { PriorityCategory } from '../../types/queue';
import { useQueue } from '../../context/QueueContext';
import { DEMO_PATIENT } from '../../data/mockData';

interface PatientAuthProps {
  onSuccess: () => void;
  onSwitchToAdmin: () => void;
}

export const PatientAuth: React.FC<PatientAuthProps> = ({
  onSuccess,
  onSwitchToAdmin
}) => {
  const [isRegister, setIsRegister] = useState(false);
  const { setCurrentPatient } = useQueue();

  // Registration state
  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('female');
  const [category, setCategory] = useState<PriorityCategory>('general');

  // Login state
  const [loginIdentifier, setLoginIdentifier] = useState('rithika.m@example.com');
  const [loginPassword, setLoginPassword] = useState('••••••••');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // In mock/demo mode, authenticate user
    setCurrentPatient({
      ...DEMO_PATIENT,
      email: loginIdentifier || DEMO_PATIENT.email,
      name: loginIdentifier.includes('rithika') ? 'Rithika M' : 'Patient User'
    });
    onSuccess();
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName) return;
    setCurrentPatient({
      id: 'PAT-' + Math.floor(1000 + Math.random() * 9000),
      name: fullName,
      mobile: mobile || '+91 98000 12345',
      email: email || 'patient@example.com',
      age: Number(age) || 30,
      gender,
      category
    });
    onSuccess();
  };

  const handleQuickDemoLogin = () => {
    setCurrentPatient(DEMO_PATIENT);
    onSuccess();
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-slate-50">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center mx-auto mb-3">
            <User className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900">
            {isRegister ? 'Patient Registration' : 'Patient Login'}
          </h2>
          <p className="text-xs text-slate-500">
            {isRegister 
              ? 'Register once to manage remote digital tokens and receive turn alerts'
              : 'Enter your credentials to access your active tokens and queue tracking'}
          </p>
        </div>

        {/* 1-Click Demo Login Banner */}
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-brand-50 to-blue-50 border border-brand-200">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold text-brand-700 uppercase tracking-wider flex items-center">
                <Sparkles className="w-3 h-3 mr-1 text-brand-600" /> Demo Evaluation
              </span>
              <p className="text-xs font-semibold text-slate-800">
                Log in as <strong>Rithika M</strong> (Token C-127)
              </p>
            </div>
            <button
              type="button"
              onClick={handleQuickDemoLogin}
              className="px-3 py-1.5 rounded-lg bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold shadow-sm transition active:scale-95"
            >
              Quick Login
            </button>
          </div>
        </div>

        {/* Form */}
        {!isRegister ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mobile Number or Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder="e.g. rithika.m@example.com or 9876543210"
                  className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-bold text-slate-700">
                  Password
                </label>
                <a href="#forgot" onClick={(e) => { e.preventDefault(); alert('Demo Mode: Click "Quick Login" or enter any password.'); }} className="text-[11px] font-medium text-brand-600 hover:text-brand-700">
                  Forgot Password?
                </a>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-brand-500/20 transition active:scale-95 flex items-center justify-center space-x-2"
            >
              <span>Login to Patient Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Rithika M"
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Mobile</label>
                <input
                  type="tel"
                  required
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-brand-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@email.com"
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-brand-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Age</label>
                <input
                  type="number"
                  required
                  min="1"
                  max="120"
                  value={age}
                  onChange={(e) => setAge(e.target.value ? Number(e.target.value) : '')}
                  placeholder="29"
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-brand-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-brand-500"
                >
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Patient Category (For Priority Triage)
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PriorityCategory)}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-brand-500"
              >
                <option value="general">General</option>
                <option value="senior">Senior Citizen (60+)</option>
                <option value="pregnant">Pregnant Mother</option>
                <option value="child">Child / Infant (&lt;12)</option>
                <option value="pwd">Person with Disability</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Choose a secure password"
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs sm:text-sm shadow-md transition"
            >
              Complete Registration & Enter
            </button>
          </form>
        )}

        {/* Toggle between Login and Register */}
        <div className="pt-2 text-center border-t border-slate-100">
          <button
            type="button"
            onClick={() => setIsRegister(!isRegister)}
            className="text-xs font-semibold text-brand-600 hover:text-brand-700"
          >
            {isRegister 
              ? 'Already registered? Login to your account' 
              : "Don't have an account? Register as New Patient"}
          </button>
        </div>

        {/* Switch to Hospital Staff */}
        <div className="text-center pt-1">
          <button
            type="button"
            onClick={onSwitchToAdmin}
            className="text-[11px] text-slate-400 hover:text-slate-600 transition"
          >
            Hospital Staff / Doctor? <strong>Switch to Hospital Login →</strong>
          </button>
        </div>

      </div>
    </div>
  );
};
