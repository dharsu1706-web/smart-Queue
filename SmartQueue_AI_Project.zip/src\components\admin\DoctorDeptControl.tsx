import React, { useState } from 'react';
import { 
  Building2, 
  Stethoscope, 
  Plus, 
  Trash2, 
  Pause, 
  Play, 
  UserPlus, 
  CheckCircle2, 
  AlertCircle,
  Clock,
  MapPin
} from 'lucide-react';
import { useQueue } from '../../context/QueueContext';
import { DoctorStatus } from '../../types/queue';

export const DoctorDeptControl: React.FC = () => {
  const { 
    departments, 
    doctors, 
    updateDoctorStatus, 
    pauseResumeQueue, 
    addDoctor, 
    removeDoctor 
  } = useQueue();

  const [newDoctorModalOpen, setNewDoctorModalOpen] = useState(false);
  const [docName, setDocName] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [departmentId, setDepartmentId] = useState('cardiology');
  const [room, setRoom] = useState('Cabin 105 - OPD Floor');
  const [avgMinutes, setAvgMinutes] = useState(12);

  const handleAddDoctorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName) return;

    const dept = departments.find(d => d.id === departmentId);

    addDoctor({
      name: docName,
      specialty: specialty || 'Specialist Physician',
      departmentId,
      departmentName: dept?.name || 'General OPD',
      room: room || 'Cabin 105',
      avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
      status: 'available',
      avgConsultationMinutes: Number(avgMinutes) || 12,
      experienceYears: 10
    });

    setDocName('');
    setSpecialty('');
    setNewDoctorModalOpen(false);
  };

  return (
    <div className="space-y-8">
      
      {/* 1. Header with Add Doctor Action */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">
            Doctor & Department Queue Controller
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Configure doctors, monitor active consultations, and pause or resume department queues.
          </p>
        </div>

        <button
          onClick={() => setNewDoctorModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-md transition flex items-center space-x-1.5 self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add New Doctor</span>
        </button>
      </div>

      {/* 2. Departments Grid (9 Departments Supported) */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900">
          Hospital Departments (9 Active Units)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {departments.map((dept) => {
            const isPaused = dept.status === 'busy' && dept.totalWaiting > 15; // Or manual pause
            const deptDocs = doctors.filter(d => d.departmentId === dept.id);

            return (
              <div 
                key={dept.id} 
                className="bg-white rounded-2xl border border-slate-200 p-5 card-shadow space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 uppercase">
                      Code: {dept.code}
                    </span>
                    <h4 className="text-base font-bold text-slate-900 mt-1">{dept.name}</h4>
                  </div>
                  <button
                    onClick={() => pauseResumeQueue(dept.id, dept.status !== 'busy')}
                    className={`p-2 rounded-xl text-xs font-semibold flex items-center space-x-1 transition ${
                      dept.status === 'busy' 
                        ? 'bg-amber-100 text-amber-800 hover:bg-amber-200' 
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                    title={dept.status === 'busy' ? 'Resume Queue' : 'Pause Queue'}
                  >
                    {dept.status === 'busy' ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                    <span>{dept.status === 'busy' ? 'Busy/Paused' : 'Active'}</span>
                  </button>
                </div>

                <p className="text-xs text-slate-500 line-clamp-2">
                  {dept.description}
                </p>

                <div className="pt-2 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded-lg bg-slate-50">
                    <div className="text-[10px] text-slate-400">Waiting</div>
                    <div className="font-bold text-slate-900">{dept.totalWaiting}</div>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-50">
                    <div className="text-[10px] text-slate-400">Avg Wait</div>
                    <div className="font-bold text-brand-600">{dept.avgWaitMinutes}m</div>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-50">
                    <div className="text-[10px] text-slate-400">Serving</div>
                    <div className="font-bold text-emerald-600 font-mono">{dept.currentServingToken}</div>
                  </div>
                </div>

                <div className="pt-1 text-[11px] text-slate-500">
                  Doctors Assigned: <strong>{deptDocs.map(d => d.name.split(' ')[1] || d.name).join(', ') || 'Rotational staff'}</strong>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Doctors Roster & Availability Controller */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900">
          Physician & Doctor Management
        </h3>

        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden card-shadow">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Doctor</th>
                  <th className="py-3.5 px-4">Department & Room</th>
                  <th className="py-3.5 px-4">Current Serving</th>
                  <th className="py-3.5 px-4">Consultation Velocity</th>
                  <th className="py-3.5 px-4">Availability Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {doctors.map((doc) => (
                  <tr key={doc.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center space-x-3">
                        <img 
                          src={doc.avatar} 
                          alt={doc.name} 
                          className="w-10 h-10 rounded-xl object-cover border border-slate-200" 
                        />
                        <div>
                          <div className="font-bold text-slate-900">{doc.name}</div>
                          <div className="text-[11px] text-slate-500">{doc.specialty}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-slate-800 font-semibold">{doc.departmentName}</div>
                      <div className="text-[11px] text-brand-600">{doc.room}</div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-emerald-600">
                      {doc.currentServingToken || '—'}
                    </td>

                    <td className="py-3.5 px-4 text-slate-600">
                      ~{doc.avgConsultationMinutes} min/patient
                    </td>

                    <td className="py-3.5 px-4">
                      <select
                        value={doc.status}
                        onChange={(e) => updateDoctorStatus(doc.id, e.target.value as DoctorStatus)}
                        className={`px-2.5 py-1 rounded-lg border text-xs font-bold capitalize ${
                          doc.status === 'available' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                          doc.status === 'busy' ? 'bg-amber-50 text-amber-800 border-amber-300' :
                          doc.status === 'in-consultation' ? 'bg-blue-50 text-blue-800 border-blue-300' :
                          'bg-slate-100 text-slate-700 border-slate-300'
                        }`}
                      >
                        <option value="available">Available</option>
                        <option value="busy">Busy</option>
                        <option value="in-consultation">In Consultation</option>
                        <option value="on-break">On Break</option>
                        <option value="offline">Offline</option>
                      </select>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      {doctors.length > 3 && (
                        <button
                          onClick={() => removeDoctor(doc.id)}
                          className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg transition"
                          title="Remove Doctor"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Doctor Modal */}
      {newDoctorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Add Doctor to Hospital Roster</h3>
            
            <form onSubmit={handleAddDoctorSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Doctor Name</label>
                <input
                  type="text"
                  required
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  placeholder="e.g. Dr. Kavita Sharma"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Specialty</label>
                <input
                  type="text"
                  required
                  value={specialty}
                  onChange={(e) => setSpecialty(e.target.value)}
                  placeholder="e.g. Senior Pediatrician"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Department</label>
                <select
                  value={departmentId}
                  onChange={(e) => setDepartmentId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                >
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Cabin / Room Location</label>
                <input
                  type="text"
                  value={room}
                  onChange={(e) => setRoom(e.target.value)}
                  placeholder="e.g. Cabin 204 - 2nd Floor"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Avg Consultation Minutes</label>
                <input
                  type="number"
                  min="3"
                  max="45"
                  value={avgMinutes}
                  onChange={(e) => setAvgMinutes(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setNewDoctorModalOpen(false)}
                  className="w-1/2 py-2 text-xs font-bold rounded-xl border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 text-xs font-bold rounded-xl bg-brand-600 text-white hover:bg-brand-700 shadow-sm"
                >
                  Save Doctor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
